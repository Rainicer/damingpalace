---
layout: post
title:  "cryptnews-20220812"
---
1、Gnosis联创：编写软件是言论自由的体现，技术是中立的  
2、ETH非零地址数量创历史新高，盈利地址数量达到3个月高点  
3、Monero（XMR）预计将于今日进行硬分叉升级  
4、10KTF Combat Crate系列NFT销售额突破130万APE，约合1000万美元  
5、区块链开发平台Infura已支持Arbitrum Goerli测试网  
6、俄罗斯计划2024年推出数字卢布并连接所有银行和信贷机构  
7、Phantom：某些NFT图像由于Meson Network的临时问题未能加载，所有NFT均安全  
8、被逮捕的Tornado Cash开发者身份确定，其妻子否认其违法  
9、巴西央行行长：不同意对加密资产进行严格监管，但加密资产托管集中度过高  
10、天桥资本创始人：预计未来加密市场将更加活跃  
