---
layout: post
title:  "cryptnews-20220913"
---
1、公链QLC Chain完成1500万美元融资，Dawnstar Capital领投  
2、迪拜豪华酒店Palazzo Versace已允许客人使用加密货币付款  
3、Telstra Ventures旗下第三支基金完成3.44亿美元募资，将推动加密领域投资  
4、三星Goldex成立黄金和加密资产银行，结合传统黄金交易平台与DEX  
5、Kraken报告：当前质押水平下，实现以太坊通缩的Base Fee阈值为15.43Gwei  
6、Swype：Arbitrum网络用户可实现银行账户法币与加密货币间兑换  
7、美国数字商会呼吁若SEC不批准比特币现货ETF可对其发起诉讼  
8、育碧CEO：旗下NFT项目处于Web3相关技术整合的研究阶段  
9、去中心化交易平台Mycelium将于以太坊合并期间在Mycelium Perpetual Swaps上免收交易费  
10、数据：超70%质押ETH的购买价格高于1700美元  
