---
layout: post
title:  "cryptnews-20230202"
---
1、Meta元宇宙部门Reality Labs 2022年亏损达137亿美元  
2、以太坊自合并以来供应量实现通缩超6,408枚ETH，创历史新高  
3、Bithumb实控人因涉嫌贪污、渎职被捕  
4、以太坊首个公共提款测试网Zhejiang已启动，下周将进行Shanghai+Capella升级  
5、前麦肯锡合伙人担任加密数据供应商Lukka首任欧洲主管  
6、Rocket Pool旨在限制自身质押ETH占比的社区提案已获99.45%投票支持  
7、Evmos发布2023年路线图，含EVM扩展、Evmos SDK和dApp商店等内容  
8、A股上市公司智度股份：2022年购买云算力所产的比特币已计提超6300万元资产减值  
9、战略咨询公司贝恩公司收购Web3数字产品工作室Umbrage  
10、欧易Web3钱包与去中心化交易平台Biswap达成官方合作  
