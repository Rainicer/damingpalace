---
layout: post
title:  "cryptnews-20221225"
---
1、数据：比特币矿企集体债务总额超40亿美元，Core Scientific、Marathon Digital和Greenidge负债最多  
2、派盾：Defrost Finance被添加虚假抵押Token且恶意清算，损失超1200万美元  
3、马斯克：已经控制住Twitter开支，没有濒临破产  
4、慢雾：Rubic协议错将USDC添至Router白名单，致授权合约用户USDC遭窃取  
5、当前比特币市值占比为38.37%，以太坊为17.41%  
6、1inch推出Fusion升级，将提高Swap安全性和盈利能力  
7、过去24小时全网爆仓2899万美元  
8、以太坊短时跌破1200美元，24小时跌幅1.24%  
9、FBI或已启动追捕Alameda另一名联席CEO Sam Trabucco和工程总监Nishad Singh  
10、元宇宙头像设计公司House of Blueberry完成约600万美元新一轮融资  
