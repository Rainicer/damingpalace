---
layout: post
title:  "cryptnews-20221127"
---
1、加拿大主要加密交易平台Coinsquare称客户数据遭到泄露  
2、彭博社：加密行业参与者向美国政客捐赠8410万美元，84%来自SBF和FTX高管  
3、马斯克公布推特2.0规划，未介绍支付功能  
4、推特2.0或将集成Signal协议推出加密私信功能  
5、瑞士移动应用开发商BIZI LABS推出集成Polygon的旗舰Web3智能手机  
6、普京呼吁构建基于区块链和数字货币的国际清算解决方案  
7、尼日利亚SEC不会计划将加密货币纳入改善数字资产交易方案  
8、前Terra研究员：Jump Trading或通过操纵Pyth喂价阻止链上仓位被清算  
9、跨链桥Across Protocol治理Token ACX将于明日正式上线  
10、受FTX崩盘影响迪拜开始质疑加密相关监管机构审批  
