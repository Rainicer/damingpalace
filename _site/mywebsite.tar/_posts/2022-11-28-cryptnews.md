---
layout: post
title:  "cryptnews-20221128"
---
1、Jump Crypto总裁：加密行业遭遇信任危机，需建立更好的信任层  
2、数据：持有1-10枚BTC的地址数量超80万，创历史新高  
3、Telegram现支持在应用聊天界面直接交易BTC和TON  
4、巴哈马总检察长：正在对FTX进行民事和刑事调查  
5、Aave停用YFI、CRV、MANA、1INCH等17个低流动性资产池以防止攻击  
6、区块链金融公司Ettle推出澳元Stablecoin AUDE  
7、DefiLlama与0xKofi合作推出合约使用情况追踪页面  
8、Coinbase：多数机构投资者在熊市期间增持数字资产，总体情绪保持乐观  
9、LINE旗下加密交易所Bitfront宣布关闭，将于明年3月全面结束运营  
10、Mirror出现宕机问题，无法访问文章  
