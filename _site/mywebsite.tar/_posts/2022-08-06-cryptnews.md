---
layout: post
title:  "cryptnews-20220806"
---
1、Web3社交游戏平台INK Games完成1875万美元融资  
2、1inch历史总交易额突破2000亿美元  
3、Voyager Digital：预计将从8月11日开始恢复美元提现  
4、The Sandbox官方Instagram帐户已恢复控制，已知1名用户受骗  
5、CZ：Binance未持有WazirX运营实体股份，仅提供钱包支持等服务  
6、数字资产数据提供商Amberdata将添加Avalanche网络  
7、WazirX CEO创立的公链项目Shardeum正在通过私人Token销售融资1800万美元  
8、蒂芙尼NFT「NFTiff」已售罄  
9、Nomad：正在与TRM Labs和执法部门合作追回资金，不会对白帽采取法律行动  
10、Meta计划发行100亿美元债券，用于股票回购和产品研发  
