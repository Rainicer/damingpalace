---
layout: post
title:  "cryptnews-20220802"
---
1、Celsius客户已聘请联合法律顾问，索赔约1.8亿美元资产  
2、Moonbeam：网络已进入维护模式，以调查所部署的智能合约的安全事件  
3、CBOE：收购ErisX后已导致4.6亿美元的资产减记  
4、比特币矿企Bitfarms：7月共开采500枚BTC，并出售1623枚BTC  
5、欧元Stablecoin规模自2020年至今增长1683%  
6、巴西数字银行Nubank：旗下加密交易平台Nucripto在三周内达到100万加密用户  
7、Coinbase Prime面向美国机构客户推出以太坊质押服务  
8、美SEC指控11人参与创建超3亿美元的加密庞氏骗局Forsage  
9、美股上市矿企Marathon完成1亿美元信贷额度融资  
10、跨链解决方案Nomad遭攻击，合约中超1.26亿美元或受影响  
