---
layout: post
title:  "cryptnews-20220821"
---
1、Aptos公布测试网3奖励标准，达成目标可获得800枚Token奖励  
2、Web3首个储蓄Token增值协议ApeParkDAO将于8月24日开启ID0  
3、Uniswap已与TRM Labs合作将253个地址拉入黑名单  
4、基于华为云的P2E链游Revoland将推出Staking功能  
5、Cryptoquant分析师：本周末加密市场下跌或因比特币超70亿美元主动卖单导致  
6、CNBC：FTX 2021年收入超10亿美元，同比增长1000%  
7、以太坊核心开发者会议：就监管提出协议级抗审查策略  
8、约50名加密和隐私倡导者在荷兰抗议Tornado Cash开发者Alexey Pertsev被捕  
9、过去一周USDC流通量减少10亿美元  
10、黑客利用零日漏洞从General Bytes旗下比特币ATM中窃取加密货币  
