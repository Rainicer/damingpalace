---
layout: post
title:  "cryptnews-20220819"
---
1、元宇宙链游BovineVerse完成194万美元融资，Zero VC等参投  
2、Animoca Brands子公司获Epic Games投资以开发赛车链游  
3、Compound启动116号提案，将在以太坊上初始化USDC市场  
4、Hodlnaut：与新加坡警方存在「未决诉讼」，已裁员80%  
5、Web3风险工作室Spartan Labs推出无代码NFT工具Puddle  
6、澳大利亚加密货币交易平台Swyftx宣布裁员21%  
7、联合国官员：控制加密货币用途有助于维护互联网安全  
8、数据：7月加密领域风险投资金额为19.8亿美元，环比下降43%  
9、Glassnode：Uniswap上USDC流动性跌至1.76亿美元，创19个月新低  
10、BendDAO首次清算拍卖BAYC，平台内20枚BAYC健康因子小于1.1  
