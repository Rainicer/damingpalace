---
layout: post
title:  "cryptnews-20220728"
---
1、Big Time推出链游基础设施Open Loot  
2、过去24小时全网爆仓达3.32亿美元  
3、Meta元宇宙部门Reality Labs第二季度亏损28亿美元  
4、Web3数据平台Coinfeeds获得200万美元种子融资，FTX和Coinbase参投  
5、Aztec Network开源EVM汇编语言Huff  
6、英国法律委员会寻求将加密货币与NFT视作新型财产  
7、NFT基础设施服务商Project Galaxy集成Moonbeam  
8、俄罗斯拟通过立法修正案规范NFT市场  
9、FTX Stocks已向美国用户开放，提供美国上市股票和ETF交易  
10、CZ：区块链融资是为当地经济融资最直接的方式，增加就业和产业  
