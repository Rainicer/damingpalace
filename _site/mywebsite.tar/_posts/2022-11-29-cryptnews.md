---
layout: post
title:  "cryptnews-20221129"
---
1、Uniswap社区新提案建议在Scroll测试网上部署Uniswap V3  
2、乌克兰暂停将Binance支付服务整合至Diia移动程序  
3、Cardano生态DEX AdaSwap正式在主网上线  
4、Muverse平台美国歌手Lamar Casey作品NFT成功售罄，社区耳机NFT空投将于今晚开启  
5、Hooked Protocol：超80万枚Gold转换为uHGT的申请将触发审核流程  
6、报告：美国拥有45.3%以太坊节点，全球排名第一  
7、万事达卡提交加密和Web3安全相关商标申请  
8、波卡生态七支团队成立链上Polkadot联盟，旨在建立社区道德规范  
9、英城市大臣：看到由法币信用担保的Stablecoin机遇  
10、乌克兰央行进一步推进数字格里夫纳项目  
