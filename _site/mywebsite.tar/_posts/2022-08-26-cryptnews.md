---
layout: post
title:  "cryptnews-20220826"
---
1、Mellow Protocol完成275万美元种子轮融资，ParaFi等领投  
2、Stargate Finance（STG）突破1美元，24小时涨幅26.45%  
3、印度执法局对印度加密交易平台CoinSwitch Kuber进行搜查  
4、NFT Genius以1.5亿美元估值完成1050万美元A轮融资，Dapper Labs等领投  
5、Binance出席菲律宾参议院银行委员会听证会介绍交易平台安全性和KYC流程  
6、美费城联储主席：加息50基点仍将是一个大的幅度  
7、比特币矿企Argo Blockchain拟筹集2500万至3500万美元，以将算力提升至4.1EH/s  
8、Web3风投基金Symbolic Capital完成5000万美元融资，Polygon联创等参投  
9、印度储备银行计划于2023年一季度发行数字卢比  
10、Web3初创公司Comm完成500万美元种子轮融资，CoinFund领投  
