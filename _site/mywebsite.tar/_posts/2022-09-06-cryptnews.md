---
layout: post
title:  "cryptnews-20220906"
---
1、Tether：5月持有美债占市场总量2%以上，超过伯克希尔哈撒韦  
2、数据：被标记为三箭资本的地址已从Curve移除20945 枚stETH  
3、BSN 推出「BSN Spartan Network」开源国际版本，可为全球IT系统提供无Token区块链服务  
4、英国财政部要求加密交易平台报告逃避对俄罗斯制裁的可疑交易  
5、以太坊Bellatrix硬分叉已经激活，将于8日后进行合并  
6、福布斯公布2022亚洲100强榜单，Gusto Collective和Merkle Science入榜  
7、Binance：目前暂无将USDT自动转换为BUSD的计划  
8、Stake DAO旗下流动性质押产品Liquid Lockers已上线Frax Finance的全部功能服务  
9、澳大利亚就加密货币征税立法向公众征求意见  
10、数据：今年已有超3600个美国商标提交元宇宙相关申请，超2021全年申请数  
