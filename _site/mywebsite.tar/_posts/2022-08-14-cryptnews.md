---
layout: post
title:  "cryptnews-20220814"
---
1、比特币突破25,000美元，24小时涨幅1.58%  
2、Cryptolingo DAO创始人：攻击者地址12亿枚aUSD尚未转移，Acala或通过公投进行回滚  
3、北京发布首个数字人产业政策，2025年产业规模将突破500亿元  
4、巴西加密借贷平台BlueBenx暂停用户提现，称遭黑客攻击损失3200万美元  
5、欧洲加密交易平台WhiteBIT拟推出Token WBT  
6、Premint：向Collector Pass社区提供白名单需进行KYC  
7、过去一周USDC流通量减少5亿美元  
8、Axie Infinity社区购入美国3x3篮球联盟Big3旗下Trilogy球队所有权NFT  
9、aUSD已跌破0.01美元，已严重脱锚  
10、Acala疑似遭遇黑客攻击，正通过紧急投票暂停操作  
