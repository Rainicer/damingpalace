---
layout: post
title:  "cryptnews-20220809"
---
1、比特币矿企Iris Energy提前启用41兆瓦的比特币矿机  
2、数字人民币「硬件钱包」电费交纳场景首单落地  
3、Aave社区拟提出新提案：仅支持合并后的PoS链  
4、Layer2协议Loopring铸造独立NFT数量突破20万枚，交易总额超1500万美元  
5、Web3原生支付基础设施提供商Airswift完成200万美元种子轮融资，CEiC领投  
6、V神：ZK-Rollups或成为以太坊主要Layer 2解决方案  
7、美国财政部高级官员：朝鲜黑客通过Tornado Cash洗钱数百万美元  
8、去中心化交易协议0x已聚合Synthetix在以太坊和Optimism上的流动性  
9、美OFAC将Tornado Cash及多个以太坊地址纳入制裁名单中  
10、美德州监管机构要求破产法院拒绝Celsius将其产出比特币变现的请求  
