---
layout: post
title:  "cryptnews-20221001"
---
1、NFT电子书初创公司Book.io完成种子轮融资，Ingram Content Group独家投资  
2、加密交易平台WazirX宣布裁员40%，交易量受多方面影响严重下滑  
3、普华永道香港与元宇宙技术公司TerraZero达成合作，拟探索元宇宙产品和服务  
4、Waves推出Waves School，旨在提供加密和区块链知识免费培训  
5、俄罗斯将为哈萨克斯坦加密矿工提供电力  
6、乌干达金融科技初创公司Numida完成1230万美元股权和债务融资  
7、Era7 WCT S1：Web3首个轻竞技赛事冠军争夺战揭幕  
8、OpenSea 9月交易额不足3.5亿美元，系过去14个月最低  
9、数据：1inch用户总量突破150万，交易总额超2100亿美元  
10、Robinhood上线Avalanche（AVAX）外部转账功能  
