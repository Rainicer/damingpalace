---
layout: post
title:  "cryptnews-20230116"
---
1、数据：比特币挖矿难度上调10.26%至37.59T，创历史新高  
2、Visa将加密支付服务商Alchemy Pay列为官方服务提供商  
3、InsurAce发布2023年路线图，将专注于增加收入、推出新产品和开发加密存款保险计划  
4、加密友好型数字银行NuBank宣布将上架MATIC和UNI  
5、俄罗斯和伊朗正着手研究由黄金支持的稳定币  
6、Curve宣布为dApp界面加入中文选项  
7、2022年共有超110个Web3创作者经济项目获得融资，总额约6.62亿美元  
8、CryptoPunk #2522以1 Wei成交，价格不足0.01美元  
9、欧易Web3钱包上线燃料（Gas）加油站功能  
10、Uniswap基金会将与StarkWare、Nethermind讨论部署Uniswap V3到StarkNet的提案  
