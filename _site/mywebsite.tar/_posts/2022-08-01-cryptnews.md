---
layout: post
title:  "cryptnews-20220801"
---
1、韩国央行：将从今年下半年开始与金融机构进行CBDC相关实验  
2、韩国釜山银行员工挪用约110万美元客户资金用于投资加密货币  
3、流动性提供商OrBit Markets完成460万美元天使轮融资，Matrixport领投  
4、Bitget设立2亿美元的交易保护基金以加强用户信任  
5、数据：7月DeFi安全事件损失1020万美元  
6、NFT系列Meebits拟允许持有者进行版权创作，将于8月15日发布IP协议  
7、北京市金融局：北京全域已经转为数字人民币试点地区  
8、ENS域名tiffany.eth以29 ETH的价格售出  
9、数据：7月OpenSea交易量相较1月历史高点下降近90%  
10、数字内容生产商Terapin Studios完成9300万美元融资，Affirma Capital和NPX Private Equity参投  
