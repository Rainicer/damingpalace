---
layout: post
title:  "cryptnews-20230128"
---
1、白宫发布《政府减轻加密货币风险路线图》  
2、美联储拒绝数字资产银行Custodia加入联邦储备系统的申请  
3、《南华早报》：香港金融管理局和香港SFC被列入FTX债权人名单  
4、Binance要求WazirX发布澄清声明，并删除服务条款中所有Binance相关内容  
5、欧易Web3钱包与Multichain达成官方合作  
6、BitPay与MoonPay达成合作伙伴关系，将提供加密货币即时购买功能  
7、Yuga Labs联创Wiley Aronow宣布因患有心力衰竭将暂时退居幕后  
8、AptosWorldTour黑客松韩国首尔站将于2月1日开幕  
9、Animoca Brands支持的元宇宙游戏平台GamesPad收购动画和电影视频制作工作室Mompozt  
10、Beosin：分布式资本合伙人沈波被盗资产地址出现异动，将400万枚DAI兑换为2496 ETH  
