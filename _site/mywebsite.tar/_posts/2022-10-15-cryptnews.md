---
layout: post
title:  "cryptnews-20221015"
---
1、国际证监会组织：监管机构应有权要求关闭外国加密货币网站  
2、《汉尼拔》男主Anthony Hopkins首个NFT作品在7分钟内售罄  
3、Devcon分享 | dForce创始人Mindao：南美加密基础很好，有现实需求  
4、美参议员：加密监管法案中的部分内容或将在6个月内通过  
5、Earning.Farm遭受闪电贷攻击，共计损失748 ETH  
6、女性Web3教育DAO创始人被曝挪用DAO资金超100万美元  
7、去中心化内容发布平台 t2.world (t2)完成340万美元融资，Inflection和Archetype领投  
8、前NEA合伙人Amit Mukherjee创立去中心化投资机构Chainforest DAO  
9、sound.xyz正式启动Season 4，170位艺术家在Season 3获得350万美元销售收入  
10、Magic Eden将启用可选版税，并推出100万美元创作者货币化黑客松  
