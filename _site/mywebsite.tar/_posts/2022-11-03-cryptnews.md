---
layout: post
title:  "cryptnews-20221103"
---
1、渣打银行将于新加坡试行贸易融资资产Token化  
2、金融服务平台Marex聘请加密技术专家推行数字资产服务  
3、Web3域名联盟成立，创始成员包括Unstoppable Domains等  
4、Instagram将内置NFT铸造和交易功能  
5、彭博社：摩根大通首次在公链上执行DeFi交易  
6、Arweave现已集成至Meta，为Instagram创作者存储数字收藏品  
7、新加坡央行行长：新加坡金管局将推出Ubin+数字货币项目，用于跨境实时结算  
8、日本数字厅将成立Web3.0研究会DAO，以研究是否赋予DAO法人资格  
9、新加坡金融管理局董事总经理：新加坡希望成为金融区块链的中心  
10、zkSync联创：重大新闻即将发布  
