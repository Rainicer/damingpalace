---
layout: post
title:  "cryptnews-20221024"
---
1、3Commas与FTX的API接口密钥确认已被利用  
2、SBF：「美CFTC加密监管草案」核心目标是规范中心化加密场所  
3、DefiLlama推出结构化策略产品Delta Neutral Yields  
4、加密投资平台Freeway已停止所有取款，疑似发生Rug pull  
5、FTX将向受网络钓鱼事件影响的账户提供约600万美元的一次性补偿  
6、CZ：Binance正在大规模投资DeFi  
7、SBF：Binance将USDC转换为BUSD开启第二次大规模Stablecoin竞争  
8、韩国金融委员会拟对持有7万美元以上虚拟资产的用户进行监测  
9、比特币全网难度升至36.84T创历史新高  
10、全球资管巨头贝莱德为Maker提供美国国债和公司债券投资服务  
