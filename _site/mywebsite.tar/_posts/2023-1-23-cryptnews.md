---
layout: post
title:  "cryptnews-20230123"
---
1、「SushiSwap将全部手续费转入Sushi DAO国库」提案投票获全票通过  
2、Chainway面向Tornado用户推出「无罪证明」工具  
3、美国首个核动力比特币挖矿中心竣工  
4、微软已解散其VR、MR工具包和头显HoloLens团队  
5、富国银行、美国银行和摩根大通等银行正研发一款数字钱包  
6、数据：2022年NFT交易达1.01亿笔，环比增长67.57%  
7、V神撰文介绍「隐形地址」概念以解决以太坊隐私保护难题  
8、Render Network宣布成立非营利组织Render Network基金会，核心代码库和品牌控制权由基金会持有  
9慢雾余弦：黑客通过Seaport协议matchAdvancedOrders函数卖出窃取NFT可绕过OpeSea安全策略  
10、巴西和阿根廷将于本周宣布开始创建统一货币的工作  
