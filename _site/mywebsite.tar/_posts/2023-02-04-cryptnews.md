---
layout: post
title:  "cryptnews-20230204"
---
1、Justin Sun：波场TRON将为ChatGPT提供去中心化支付框架  
2、处于盈利状态的ETH地址数占比达到61.823%，创下5个月以来最高点  
3、NFT公司Limit Break将斥资650万美元在超级碗投放广告  
4、Web3社交平台D3D与MEXC合作上线首个socialfi类加密货币D3D  
5、多个主流DeFi项目于推特发布「碰拳」图片，或将于下周发布重要消息  
6、Microstrategy创始人：查理·芒格若处于第三世界，会比我更加看好比特币  
7、Ray Dalio：加密货币若能代表抗通胀的「购买力存储」会是一种好资产  
8、Filecoin开发公司Protocol Labs宣布裁员21%  
9、CFTC主席：CFTC有能力填补加密领域的监管空白  
10、Cool Cats与Hologram Labs达成合作为NFT持有者提供3D头像  
