---
layout: post
title:  "cryptnews-20230131"
---
1、加密支付应用Strike向菲律宾扩张以发展其跨境支付和汇款市场  
2、MetaMask Learn课程中文版已上线，旨在帮助用户理解Web3概念  
3、区块链安全公司Sec3完成1000万美元种子轮融资，Multicoin Capital领投  
4、全球资管公司Hamilton Lane已设立首支Token化基金  
5、特斯拉：2022年因比特币减值损失2.04亿美元  
6、破产法院同意BlockFi出售其加密矿业资产用于偿还债权人  
7、dYdX发布2022年度报告：协议累计交易量4663亿美元，活跃交易者达3.39万  
8、OpenSea已重新部署NFT类别页面，新增游戏选项  
9、SBF曾试图拖延FTX破产程序以转移资产至外国监管机构  
10、金融时报：Twitter在美国申请州级许可证，以开展支付业务  
