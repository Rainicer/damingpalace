---
layout: post
title:  "cryptnews-20230127"
---
1、高盛发言人：高盛未持有FTX债权  
2、数据：Polygon日活用户超过以太坊，成为DAU第二大区块链  
3、Aave V3已部署至以太坊主网  
4、ApeCoin DAO发起新提案拟新增投票「弃权」选项  
5、DeFi收益协议Timeless Finance已开放空投申领  
6、美国SEC再次拒绝ARK和21Shares联合发行比特币现货ETF的申请  
7、高盛发言人：高盛未持有FTX债权  
8、LayerZero与NFT项目「胖企鹅」达成合作，实现Lil Pudgys跨链  
9、美国SEC再次拒绝ARK和21Shares联合发行比特币现货ETF的申请  
10、Solana生态NFT平台Metaplex已在主网部署可编程NFT  
