---
layout: post
title:  "cryptnews-20230205"
---
1、a16z投票反对在BNB Chain上部署Uniswap V3，希望部署采用LayerZero桥接  
2、Aave V3在以太坊上的市场规模突破1亿美元  
3、去中心化社交协议Nostr账户总量突破72万  
4、比特币网络NFT协议Ordinals铸造NFT接近3千枚，2月4日单日铸造破千枚  
5、Arbitrum链上活跃用户数突破200万，总交易笔数突破1亿  
6、SBF名下此前挂牌出售的华盛顿特区联排别墅已从市场下架  
7、数据：Arbitrum网络总锁仓量达13.6亿美元，7日涨幅13.23%  
8、TON推出2000万美元流动性激励计划「The Open Challenge」  
9、多名投资人宣布退出前Moonbirds首席运营官Ryan Carson创立的新Web3项目「Flux」  
10、Huobi将上架FTX用户债权Token FUD，进入债权理赔市场  
