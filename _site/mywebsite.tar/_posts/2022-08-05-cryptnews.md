---
layout: post
title:  "cryptnews-20220805"
---
1、Binance Card宣布支持XRP、SHIB和AVAX  
2、数据：自EIP-1559实行一年以来，已销毁超250万枚ETH  
3、美国7月季调后非农就业人口52.8万人，创今年2月以来最大增幅  
4、数字藏品交易平台「元镜 MetaMirror」H5支付于今日正式上线  
5、以太坊突破1700美元，24小时涨幅4.96%  
6、调查：近7%的西班牙人曾投资加密货币  
7、Bitget宣布成为DOTA 2 Major Arlington 2022官方合作伙伴  
8、CZ会见中非共和国总统，讨论加密货币等话题  
9、花旗：将Coinbase目标价从6美元上调至7美元  
10、区块链众筹平台FiNANCiE母公司完成约580万美元融资，MTG Ventures等参投  
