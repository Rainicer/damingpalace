---
layout: post
title:  "cryptnews-20221019"
---
1、a16z：重新启动Web3初创者加速器计划「Crypto Startup School」，申请开放至11月30日  
2、Twitter创始人资助的去中心化社交项目Bluesky重命名为AT协议，将发布Bluesky App  
3、Messari：1inch在2022 Q3交易量几近减半，收入环比下跌84%  
4、SBF：拟议的「Stabenow-Boozman法案」将为CEX加密用户提供保护  
5、美参议院委员会将就与美SEC签署数字商品定义进行谈判  
6、Celer与Oasys达成合作，将Celer IM和cBridge作为互操作层集成至Oasys生态  
7、电商巨头Shopify与Novel合作允许其平台用户直接购买NFT  
8、拉美加密交易平台Lemon与多链协议TravelX集成，支持以加密货币购买机票  
9、香港特首李家超：虚拟资产方面，政府已提交条例草案建议引入有关服务提供者的法定发牌制度  
10、香港特首李家超：香港目前处理全球约75%的离岸人民币结算，会强化最大离岸人民币业务中心优势  
