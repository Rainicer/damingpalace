---
layout: post
title:  "cryptnews-20221227"
---
1、慢雾：已冻结部分BitKeep黑客转移资金  
2、钟表品牌天美时TIMEX成为《堡垒之夜》官方「元宇宙计时器」并推出「Race Against TimeX」挑战  
3、技嘉GIGABYTE推出首个Web 3社区并在Polygon上发行AFWC NFT系列  
4、OKLink：BitKeep黑客地址链上资产往来总额达3100万美元  
5、印度Web3应用程序商店Dapps完成pre-seed轮融资，Polygon前高管等参投  
6、流出电邮显示多位FTX董事来自美国商品期货交易委员会  
7、CertiK：Defrost Finance项目为退出骗局，其团队并未进行KYC  
8、Defrost Finance：黑客已归还约1288万美元被盗资金，将尽快返还给用户  
9、富达已提交NFT、元宇宙和虚拟房产等相关商标申请  
10、波士顿联储与MIT已合作完成CBDC可行性研究项目「汉密尔顿计划」  
