---
layout: post
title:  "cryptnews-20221221"
---
1、数据：以太坊信标链验证者数量超49万，总质押价值突破200亿美元  
2、比特币矿企Northern Data 2022年收入达1.9亿欧元  
3、股票交易平台Superhero取消与加密交易平台Swyftx合并  
4、印度央行行长：加密货币对宏观经济、金融稳定有风险  
5、Web3初创公司Tonsnipe完成10万美元私募轮融资  
6、黄立成0x020c开头地址过去7日从Uniswap买入14.8万枚APE用于质押  
7、保时捷NFT已正式开放注册，铸造日定为1月23日  
8、CNBC：最大比特币矿企Core Scientific正申请第11章破产保护  
9、Sifchain核心开发者：将关闭RedStarling验证器，用户可转出Sifchain上相关资产  
10、DeFi收益率市场Pendle集成Chainlink Automation以支持vePENDLE池投票  
