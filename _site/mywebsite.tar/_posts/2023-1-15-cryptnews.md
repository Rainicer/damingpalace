---
layout: post
title:  "cryptnews-20230114"
---
1、以太坊非零钱包地址数创历史新高  
2、当前比特币市值占比为39.59%，以太坊为18.3%  
3、Binance已支持Google One Tap直接登录或注册  
4、Animoca Brands旗下NFT系列Mocaverse已开放Mocalist注册  
5、萨尔瓦多拟通过发行BTC债券筹集10亿美元用于建立「BTC城市」和购买BTC  
6、Polygon PoS链硬分叉将于1月17日进行，验证者需提前更新节点  
7、韩国友利银行将于2023上半年推出元宇宙分行  
8、Solana市值超越Polygon重返加密货币前十  
9、BAYC最新短片上线，1月17日起BAYC/MAYC持有者将可免费领取Sewer Pass  
10、Nexo联创严厉否认保加利亚对其指控  
