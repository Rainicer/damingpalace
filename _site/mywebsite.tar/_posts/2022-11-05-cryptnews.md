---
layout: post
title:  "cryptnews-20221105"
---
1、武汉正式发布促进元宇宙创新发展方案，删去NFT相关内容  
2、Immutable推出强制执行以太坊上NFT版税的工具  
3、公链Elrond Network已转型并更名为MultiversX  
4、彭博社：英国数字、文化媒体和体育委员会将开始探究NFT并研究区块链技术  
5、纽约联储完成一项CBDC测试，将跨境结算用时从2天缩短至15秒  
6、互联网之父：Web3根本不是web  
7、阿根廷独角兽数字银行Uala推出加密交易服务，目前支持BTC和ETH  
8、RabbitHole正招聘增长主管，负责规划Token空投及分配事宜  
9、Huobi Global现己完成GALA更名及兑换业务，将开放PGALA和GALA现货交易  
10、加密货币公司CloudWalk成为巴西央行授权的首家支付机构  
