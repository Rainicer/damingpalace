---
layout: post
title:  "cryptnews-20221202"
---
1、支付巨头Stripe推出面向Web3企业的法币到加密货币支付产品  
2、美CFTC主席建议重新审视《数字商品消费者保护法》，确保没有任何漏洞  
3、Magic Eden启动强制执行创作者版税的新协议Open Creator Protocol  
4、Circle Yield在偿还客户本息后不再接受新资金  
5、数据：FTX爆雷后，11月DEX交易额环比增长93%  
6、Discord宣布即日起美国创作者可在平台上赚取创作收益  
7、Tether点名批评WSJ和CoinDesk：不了解加密市场，对FTX和DCG心存偏袒  
8、Ankr攻击事件匿名套利者以10BNB成本获利超1550万美元  
9、韩国能源巨头Daesung风投子公司成立规模达8450万美元元宇宙基金  
10、阿里云拟与PlatON、HashKey合建Web3开发者平台  
