---
layout: post
title:  "cryptnews-20220815"
---
1、数据：zkSync桥接存储总价值接近16万枚ETH  
2、CryptoQuant报告：BTC矿工最新抛售可能会在短期内迫使价格下跌  
3、津巴布韦央行行长：已制定CBDC采用路线图  
4、数据：aUSD已回升至0.9013美元  
5、以太坊分叉项目ETHW Core初始版本发布，将禁用难度炸弹  
6、数据：MM Finance Polygon链上总锁仓量超3亿美元  
7、数据：8月5日至今ARK基金减持超18万股Coinbase股票  
8、Uniswap「费用开关」共识确认提案获得通过，或将进入最终投票阶段  
9、Coinbase将Ooki Protocol（OOKI）添加至路线图资产列表  
10、沉睡近3年的以太坊巨鲸地址分多笔转出14.5万枚ETH  
