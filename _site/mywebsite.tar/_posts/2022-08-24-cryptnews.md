---
layout: post
title:  "cryptnews-20220824"
---
1、以太坊客户端Geth发布v1.10.22修补程序  
2、蚂蚁集团与马来西亚私人投资银行Kenanga Investment Bank Berhad合作开发加密友好型钱包和交易应用程序  
3、Compound将于2日后启动多链借贷协议Compound III  
4、Element Black宣布将于9月1日在香港举办第二届音乐人线下见面会  
5、旅游预订平台Travala.com已支持Polygon网络USDC支付  
6、Meta推出元宇宙身份系统Meta accounts与Meta Horizon Profiles  
7、上海发布首款城市数字艺术品「申生不息」系列  
8、PancakeSwap与Stargate合作推出PancakeSwap Bridge跨链桥  
9、LooksRare推出3FACE NFT拍卖报价赢白名单活动  
10、零清算借贷算稳协议Chao&Orders宣布跨链BNBChain  
