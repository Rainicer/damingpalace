---
layout: post
title:  "cryptnews-20221003"
---
1、Celsius创始人在公司破产前取款1000万美元  
2、LooksRare将更新挂单奖励机制，仅认证系列可获得奖励  
3、数据：9月交易平台交易量升至7330亿美元，环比增长16%。  
4、Gitcoin将于10月3日至31日举办首届ODS黑客松活动，总奖金达18,250美元  
5、Robinhood因增长计划受阻拟关闭更多办事处  
6、Coinbase：美国银行账户交易故障系创建ACH转账时遇到技术问题，目前该问题已解决  
7、CZ：Binance将完全遵守新西兰法律法规及监管机构监督  
8、网坛传奇人物莎拉波娃：投资MoonPay是基于多样化投资组合策略  
9、数据：Optimism桥接存储总价值突破40万枚ETH  
10、加密游戏公司double jump.tokyo与以太坊L2解决方案zkSync达成合作  
