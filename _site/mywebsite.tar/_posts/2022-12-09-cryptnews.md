---
layout: post
title:  "cryptnews-20221209"
---
1、Gnosis Chain完成合并，共识机制过渡至PoS  
2、美立法者提出加密资产环境透明度法案，将打击能源密集型加密挖矿活动  
3、以太坊和非EVM兼容链开发者活动在2022年显着下降  
4、去中心化流媒体平台Livepeer集成Aptos网络  
5、Bybit将从12月15日起实行新KYC政策  
6、知情人士：Amber Group终止与切尔西的赞助协议，将裁员超300人  
7、以太坊核心贡献者补偿计划Protocol Guild累计获970万美元捐赠，已分发500万美元  
8、GameStop：Q3亏损近9500万美元，将不再专注于加密货币  
9、推特将为客户公司提供更多的广告投放控制权  
10、Coinbase呼吁用户将USDT换为USDC，并将免除转换手续费  
