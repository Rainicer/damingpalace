---
layout: post
title:  "cryptnews-20230212"
---
1、万向区块链肖风：数字经济中使用权比所有权更重要，Token或是互联网平台反垄断的最佳解决方案  
2、《富爸爸穷爸爸》作者：将在市场崩盘时买入更多比特币  
3、巴西银行Banco do Brasil与Bitfy合作支持用户使用加密货币纳税  
4、Cathie Wood：美国监管机构打击中心化质押将损害美国在Web3领域的竞争力  
5、Binance：已将TRON（TRX）网络提现手续费恢复至调整前的水平  
6、Nexo将于4月1日起停止为美国客户提供Earn Interest服务  
7、数据：GMX单日费用于2月10日创下564万美元历史新高  
8、派盾：Justin Sun将约3300万枚USDT存入Aave借贷池V2  
9、数字资产管理平台Oryy加入Kava Rise开发者激励计划  
10、BendDAO平台存款和借入TVL突破14万枚ETH，创历史新高  
