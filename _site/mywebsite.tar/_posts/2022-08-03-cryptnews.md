---
layout: post
title:  "cryptnews-20220803"
---
1、数据：前10大交易平台ETH当前持有量已达700万枚  
2、高盛、摩根大通因推特收购事件被马斯克要求传唤出庭  
3、Aglaé Ventures将推出1亿欧元Web3基金，专注投资加密初创公司  
4、Tether于波场网络增发10亿枚USDT  
5、Solana官方：被盗事件或与Solana核心代码无关，而和用户使用的钱包有关  
6、BitValue Capital推出1亿美元Web3增长基金  
7、Coinbase Prime面向美国机构客户推出以太坊质押服务  
8、万事达卡CFO：将继续在加密和电子商务等领域扩张  
9、Solana钱包大规模被盗事件中受波及钱包已超9000个  
10、Binance联合创始人何一将领导Binance Labs  
