---
layout: post
title:  "cryptnews-20221106"
---
1、V神发布更新版以太坊路线图，详细展示各阶段里程碑  
2、WSJ：加密行业已为美国中期选举投入7300万美元，超过国防、汽车行业总和  
3、Solana已集成Instagram和Facebook，用户可展示其NFT藏品  
4、汇丰银行将推出区块链债券Token化平台HSBC Orion  
5、Google Cloud宣布与Solana达成合作，明年将为Solana引入区块链节点引擎并添加BigQuery支持  
6、Animoca CEO：没有Web3就没有元宇宙  
7、CZ阐述支持马斯克收购推特六大原因：支持言论自由、推特有巨大潜在开发价值等  
8、推特正式启动「蓝V认证」付费制，每月收费8美元  
9、Messari：Filecoin Q3存储数据量为211个PiB，环比增长82%  
10、pNetwork：此前「砸空」pGALA池系检测到高安全风险，抽干BNB资金将返还给无抵押pGALA持有者  
