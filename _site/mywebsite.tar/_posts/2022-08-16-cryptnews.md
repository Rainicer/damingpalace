---
layout: post
title:  "cryptnews-20220816"
---
1、蒂芙尼NFT「NFTiff」地板价触及60 ETH，较发行价涨幅100%  
2、纳斯达克上市矿企Moxian出售中国子公司Moxian (Hong Kong) Limited全部股权  
3、老虎环球基金第二季度清仓Robinhood，美股持仓总规模腰斩  
4、Aave：目前钱包监控仅在前端，合约级审查将需要DAO共识  
5、以太坊短时跌破1900美元  
6、加密交易平台Coinify获批在意大利运营  
7、加密货币托管公司BitGo计划起诉Galaxy Digital，并寻求1亿美元赔偿  
8、Cosmos质押协议Stride将向ATOM、OSMO与JUNO质押者发放Token空投  
9、金融服务公司Eqonex将关闭其加密交易平台业务  
10、欧盟将创建新反洗钱监管机构以监管加密货币  
