---
layout: post
title:  "cryptnews-20220924"
---
1、Michael Saylor：比特币已触底，未来有望重回6万美元以上  
2、莫斯科交易平台正起草数字金融资产和证券交易法案  
3、韩国官方近两年已从涉嫌逃税者处扣押约1.84亿美元加密资产  
4、苹果对通过iOS应用内进行的NFT交易收取高达30%的佣金  
5、Michael Saylor：比特币已触底，未来有望重回6万美元以上  
6、V神：狗狗币和Zcash等区块链应转向PoS  
7、富国银行主管加入加密大宗经纪公司Floating Point Group担任市场营销总监  
8、韩国区块链软件开发公司Onbloc推出Gnoland网络浏览器Gnoscan  
9、Amber Group已完成对日本加密交易平台DeCurret的收购  
10、世界经济论坛发起加密可持续性联盟  
