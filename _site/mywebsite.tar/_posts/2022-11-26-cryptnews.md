---
layout: post
title:  "cryptnews-20221126"
---
1、ConsenSys创始人：RPC提供商收集IP地址是现阶段dApp运行的必要程序，Infura不会利用用户数据  
2、Bitget携手梅西开展系列活动和奖励计划  
3、马克·库班：不会离开加密领域，因为其潜在价值不会改变  
4、DYDX关于「关闭现有安全质押模块」提案已通过  
5、美国会议员对SEC主席实施的加密生态系统监管策略表示担忧  
6、Ripple诉讼律师：SBF若被捕可能会获得较轻的刑罚  
7、Akula创始人质疑Paradigm旗下Reth抄袭其代码  
8、Kraken CEO：储备金证明应包含客户负债总额，否则将毫无意义  
9、嘉楠科技或将提供和出售代表A类普通股的ADS，总发行价最高可达7.5亿美元  
10、Band Protocol将作为预言机提供商部署至Sei网络  
