---
layout: post
title:  "cryptnews-20221125"
---
1、比利时金融服务和市场管理局讨论加密资产属性  
2、MakerDAO将支持GnosisDAO治理Token GNO进行抵押民意投票  
3、以太坊开发者：扩容方案EIP-4844第三期开发者网络将于11月30日发布  
4、以太坊开发者发布用于测试质押提款功能的devnet  
5、索尼收购元宇宙体育门户平台Beyond Sports  
6、新加坡金管局：加密实体破产未对全球金融体系产生重大影响  
7、Crypto KOL许志宏：Fans Token是区块链领域最伟大的创新  
8、Binance发布默克尔树BTC资产储备证明  
9、香港财政司司长：将为虚拟资产服务供应商推出新的发牌制度  
10、Bitwise再次向美SEC提交比特币期货ETF申请  
