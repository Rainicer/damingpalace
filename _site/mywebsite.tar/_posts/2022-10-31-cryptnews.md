---
layout: post
title:  "cryptnews-20221031"
---
1、以扎克伯格为大反派角色的Web3游戏The Rabbit Hole最早将于今年Q4发布  
2、StarkNet将在Goerli上启动第二个测试网，并向社区征集命名  
3、马斯克拟终止免费用户认证，每月收取19.99美元  
4、香港发表虚拟资产政策宣言，对Token化资产的产权和智能合约的合法性持开放态度  
5、CrossSpace创始人：香港特区政府将设立40亿美元科技基金支持金融科技发展  
6、基于zkSync的Layer3区块链Opportunity或将于2023年Q1上线  
7、STEPN已于9月受邀在香港数码港设立区域总部  
8、将Aave V3部署至zkSync 2.0测试网投票已开启，已获99.97%同意选票  
9、Binance于爱尔兰成立新子公司Binance Global Sourcing  
10、The Information发布「50家最有前途初创公司」榜单，dYdX、Nansen等6家加密公司上榜  
