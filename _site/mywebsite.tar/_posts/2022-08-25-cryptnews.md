---
layout: post
title:  "cryptnews-20220825"
---
1、GMX社区提案提议降低GLP中USDC权重，分配至FRAX  
2、CZ回应「世界小姐」秦泽文相关传闻：一起吃过饭，其他不属实  
3、Reddit开始空投基于Polygon 的「收藏头像」，四个系列可在OpenSea交易  
4、读卖新闻：日本官方计划改革税制，以防止加密初创企业流向海外  
5、欧易Web3钱包正式上线完整版跨链Swap  
6、Binance合约将停止支持混合保证金功能  
7、比特币ATM公司Bitcoin Depot拟通过SPAC在纳斯达克上市，估值约8.85亿美元  
8、美SEC希望提交90页材料为其诉Ripple案动议提供支持  
9、Element Black旗下音乐NFT平台Music Infinity将于8月31日在APENFT发售AKON Music NFT  
10、Coinbase、OpenSea入选2022 Y Combinator最具突破性企业名单  
