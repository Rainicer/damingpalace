---
layout: post
title:  "cryptnews-20220909"
---
1、欧盟知识产权局设计使用区块链和NFT打击假冒商品的系统  
2、PandaDAO社区发布Token销毁提案  
3、国家版权局等四部门：强化NFT数字藏品等网络新业态版权监管  
4、StarkWare将在以太坊合并后仅支持PoS链  
5、Maker将在以太坊合并完成后仅支持PoS链，并提醒用户预防重放攻击  
6、V神发文：ENS域名非常便宜，或应引入经常性费用以增加DAO收入  
7、Avalanche链上NFT销售总额突破4亿美元  
8、苏州、广州、武汉、郑州、昆明获批建设国家区块链发展先导区  
9、Web3音乐基金Coop Records完成1000万美元融资，将直接投资音乐人和NFT  
10、Whampoa Group拟于Q4推出1亿美元数字资产投资基金  
