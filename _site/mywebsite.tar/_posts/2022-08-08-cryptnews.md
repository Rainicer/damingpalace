---
layout: post
title:  "cryptnews-20220808"
---
1、彭博：加密公司在体育领域的广告赞助已超24亿美元  
2、Aave将V3上sUSD供应量上限提升至2000万的提案投已获投票通过  
3、数据：MetaMask Swaps累计成交额突破200亿美元，累计成交量超500万笔  
4、Polygon链游Dragoma疑似Rug Pull，Token DMA暴跌逾99%  
5、DCG CEO：不支持任何以太坊PoW分叉，矿工应将算力转移至ETC  
6、摩根士丹利正在招聘专注于构建新加密产品的产品经理  
7、WazirX：目前加密货币和INR提现仍正常进行  
8、Chainlink：协议及服务不支持以太坊PoW等分叉  
9、Nomad：正努力协调资金返还，请用户积极举报相关诈骗行为  
10、Meta同意推迟收购VR公司Within Unlimited  
