---
layout: post
title:  "cryptnews-20221022"
---
1、日本JVCEA副主席：将仅针对部分加密Token取消预审核流程  
2、国际刑警组织推出专为全球执法部门设计的元宇宙  
3、支付公司Block正大量招聘比特币挖矿和钱包相关人才  
4、SBF和a16z创始人支持的2个加密PAC将在美国中期选举投放大量广告  
5、美国国会或在年底前签署《数字商品消费者保护法》  
6、Optimism生态Layer2DAO遭遇攻击，近5000万枚Token被盗  
7、Maple Finance收紧贷款标准，要求借款人签署提交财务审计、月度报告等法律协议  
8、派盾：OlympusDAO黑客已将窃取资金归还  
9、BitKeep上线用户赔付门户，并通过APP向受害者发送通知  
10、The Sandbox将自10月25日起停用MATIC/SAND质押池  
