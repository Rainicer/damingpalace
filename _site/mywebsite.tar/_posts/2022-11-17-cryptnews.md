---
layout: post
title:  "cryptnews-20221117"
---
1、Gemini理财产品暂停提现
2、zkSync开发公司Matter Labs完成2亿美元融资，Blockchain Capital和Dragonfly共同领投  
3、ENS域名重定向网站项目ENS Redirect正式推出  
4、空头机构香橼：将继续做空ETH，相信其与FTX一样存在常识性缺陷  
5、StarkNet Token合约已部署至以太坊主网  
6、淡马锡：决定全部减记向FTX、FTX US累计投资的2.75亿美元  
7、阿迪达斯发布首个NFT可穿戴系列Virtual Gear ，包含BAYC联名连帽衫  
8、萨尔瓦多总统：从明天起每天购入一枚比特币  
9、Arbitrum：Arbitrum One网络新增验证者节点  
10、微软浏览器Microsoft Edge现已支持欧易插件钱包  
