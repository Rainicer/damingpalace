---
layout: post
title:  "cryptnews-20230211"
---
1、彭博社：PayPal因监管问题暂停稳定币项目，原定于几周后推出  
2、Optimism推出链上治理门户Optimism Agora  
3、安全公司Unciphered成功破解硬件钱包OneKey，后者已更新补丁并支付赏金  
4、俄央行行长: 俄罗斯央行准备允许在对外结算中使用加密货币  
5、印度财长：正在与G20国家讨论通过共同框架监管加密货币的必要性  
6、IMF：萨尔瓦多应避免通过发行Token化证券为购买比特币融资  
7、V神再次向土耳其赈灾地址捐助99 ETH，约合15万美元  
8、Lens Protocol Profiles地板价涨至100 USDC，24小时成交量增16%  
9、Ark Invest于本周五增持约16.2万股Coinbase股票  
10、区块链存储协议Arweave发布2.6版本，硬分叉预计将于3月6日激活  
