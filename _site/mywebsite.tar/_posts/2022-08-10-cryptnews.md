---
layout: post
title:  "cryptnews-20220810"
---
1、Coinbase Q2财报：净亏损约11亿美元，交易收入环比下降35%  
2、Curve Finance遭域名攻击被盗57万美元，提醒用户立即解除授权  
3、Aave社区拟提出新提案：仅支持合并后的PoS链  
4、匿名加密用户正在通过Tornado Cash向知名人士发送ETH  
5、Arbitrum Nova已面向所有用户开放  
6、Circle：将在以太坊合并完成后仅支持PoS链  
7、Reddit社区积分将迁移至Arbitrum Nova链  
8、FTX宣布整合Reddit社群积分币，将支持在FTX Pay交易和支付  
9、Polygon推出适用于Gnosis Safe的PoS桥Gnosis Bridge  
10、彭博：泰国将彻底改革其数字货币法案规则，并赋予央行更多权利  
