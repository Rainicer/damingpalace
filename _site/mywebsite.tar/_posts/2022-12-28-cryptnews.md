---
layout: post
title:  "cryptnews-20221228"
---
1、惠誉：巴塞尔委员会的新加密标准可能会阻止银行发放由加密资产支持的贷款  
2、Defrost Finance否认「骗局」指控，称正努力将被盗资金返还给受损用户  
3、Galaxy将以6500万美元收购比特币矿企Argo的Helios设施，并向其提供3500万美元贷款  
4、Justin Sun：网传套现传闻不实，系稳定币间换链操作  
5、Zhu Su：美SEC去年阻止的Coinbase Lend实际上挽救了Coinbase  
6、中国数字资产交易平台将于2023年1月1日上线  
7、法国国家橄榄球联盟在Tezos上推出NFT平台Legendary Plays  
8、嘉楠耘智：2022年度总收入预计将达到6.19亿美元  
9、MicroStrategy宣布增持2500枚BTC，目前持有132,500枚BTC  
10、BNB信标链测试网将于1月进行爱因斯坦升级  
