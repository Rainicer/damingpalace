---
layout: post
title:  "cryptnews-20220918"
---
1、韩国科学与信息通信技术部计划制定专门的元宇宙法规  
2、莱特币网络已累计处理1.28亿笔交易  
3、以太坊客户端Teku发布22.9.1版本，改进主网合并后性能问题  
4、波卡公布黑客松获胜项目  
5、Space ID .bnb域名总注册量突破20万个  
6、Metaplex即将推出治理Token MPLX，同时将进行空投  
7、Yuga Labs聘请Spencer Tucker担任该公司首任首席游戏官  
8、Web3社交媒体平台Parler完成1600万美元B轮融资，资方信息暂未披露  
9、Metaplex即将推出治理Token MPLX，同时将进行空投  
10、比特币跌破20,000美元，24小时跌幅0.09%  
