---
layout: post
title:  "cryptnews-20221211"
---
1、Alameda前CEO聘请前SEC执法主管担任律师  
2、The Beacon或将与NFT项目DigiDaigaku达成合作，为其持有者免费提供独家NFT  
3、英格兰银行向私营部门钱包提供商征集CBDC样本钱包概念证明  
4、Coinbase CEO：加密信任危机和监管的进一步发展或将促进USDC的使用  
5、因Blur将发布第三轮空投，BAYC、Azuki等蓝筹NFT 24小时交易额均超大幅度上涨  
6、欧盟：成员国超1000欧元的加密货币交易将受到VASP尽职调查  
7、海南发放首笔4300万元数字人民币贷款  
8、三星电子或将于明年为开发者推出XR设备，已成立XR设备研发特别工作组  
9、中国太保推出全国首个数字货币账户资金损失保险  
10、NFT市场Blur昨日交易额达26,129 ETH，超过OpenSea平台四倍  
