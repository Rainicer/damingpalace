---
layout: post
title:  "cryptnews-20230208"
---
1、微软正式将ChatGPT引入必应  
2、2023年超级碗赛事禁止加密公司投放广告  
3、「胖企鹅」Pudgy Penguins推出苏富比SBT  
4、Gate Charity为土耳其地震灾后重建捐款100万里拉，并推出慈善NFT募捐活动  
5、ENS域名chatgpt.eth以6 ETH价格成交  
6、DeFi借贷协议Euler「部署至BNB Chain」提案已获投票通过  
7、沉寂超10年的比特币地址转出412枚比特币，浮盈超958万美元  
8、彭博社：迪拜虚拟资产监管局计划将员工人数增加四倍  
9、去中心化衍生品交易平台Bluefin上线Abitrum  
10、Lens Protocol Profiles持有地址总数突破10万  
