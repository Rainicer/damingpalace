---
layout: post
title:  "cryptnews-20220902"
---
1、Web3医疗大数据协议DeHealth将空投30万美元DHLT Token  
2、Synthetix将在以太坊合并前约3小时暂停协议绝大多数功能  
3、前CFTC专员Jill Sommers加入FTX US Derivatives董事会  
4、Robinhood已上线Cardano（ADA）  
5、美元指数DXY现报109.82，创20年以来新高  
6、加密技术公司WonderFi Technologies将收购区块链开发公司Blockchain Foundry  
7、1inch将向Optimism网络1inch钱包用户空投发放30万枚OP Token  
8、CZ回应陈光英传闻：陈非官方代理人，Binance不是中国公司  
9、Safe空投分发提案拟将快照日期延长至8月18日  
10、dYdX向用户发放奖金，领取人需开启摄像头进行真人验证  
