---
layout: post
title:  "cryptnews-20230201"
---
1、MakerDAO设立「Defense Fund」提案获投票通过，将分配500万DAI以在需要时支付法律辩护费用  
2、Cathie Wood：非常看好加密行业，仍维持比特币将涨至50万美元的预期  
3、BitMEX前首席产品官加入Arrington Capital任首席投资官  
4、BNB Chain发布BNB Greenfield白皮书，旨在革新数据所有权经济  
5、NFT忠诚度解决方案提供商Cohort完成320万欧元种子轮融资，Axeleo Capital等领投  
6、Irene Zhao创立的Web3社交平台SO-COL已在主网Socol.xyz部署平台质押协议  
7、CoinShares将CoinShares Physical Ethereum ETP管理费用降至0  
8、加密货币做市商B2C2与Blockdaemon和Stakewise合作为sETH提供流动性  
9、韩国金融委员会命令该国五大加密交易平台下架具有证券性质的虚拟资产  
10、以太坊零知识协处理器Axiom演示版上线  
