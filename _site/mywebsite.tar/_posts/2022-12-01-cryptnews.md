---
layout: post
title:  "cryptnews-20221201"
---
1、苹果要求Coinbase Wallet iOS必须通过其应用内购买系统支付Gas费  
2、MetaMask已集成至俄罗斯最大银行Sber旗下区块链平台  
3、英国财政大臣：FTX破产不会改变英国成为加密中心的议程  
4、全球最大交易经纪商TP ICAP获英国加密货币牌照  
5、Web3开发者平台Fleek完成2500万美元A轮融资，Polychain Capital领投  
6、曾获SBF支持的《数字商品消费者保护法》将成为美国国会首次FTX听证会主要议题之一  
7、The Graph将增加对Polygon的支持，Polygon将参与The Graph的MIPs激励计划  
8、WSJ：Tether的贷款给Stablecoin和加密世界带来未知风险  
9、Harbor Protocol将于12月5日发放Token HARBOR空投  
10、加密教育非营利组织Web3 Working Group完成200万美元融资，The Graph等参投  
