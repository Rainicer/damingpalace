---
layout: post
title:  "cryptnews-20230215"
---
1、索罗斯基金管理公司投资MicroStrategy等加密货币公司  
2、去中心化信息信誉市场Ideamarket将停止运行，可在3月1日前通过官网提取资金  
3、Lido DAO提出四项与金库相关治理提案，包括是否应出售金库中的ETH  
4、CapsuleNFT推出可在以太坊主网访问的比特币NFT系列Ordinary Oranges  
5、星展银行：星展银行数字交易平台2022年的比特币交易额上涨80%  
6、黄立成已出售95.9万枚BLUR，出售均价为0.62美元  
7、Web3社交协议CyberConnect与BNB Chain合作举办Web3社交黑客松活动  
8、韩国监管机构计划调查当地交易平台的加密质押服务  
9、中国电信将与Conflux Network合作在香港试行支持区块链的SIM卡  
10、阿布扎比启动20亿美元计划以加速Web3初创公司发展  
