---
layout: post
title:  "cryptnews-20221217"
---
1、韩国游戏巨头Wemade链游平台WEMIX PLAY推出游戏Token兑换服务  
2、福布斯：审计机构Armanino或将停止为加密货币客户服务  
3、元宇宙基础设施公司Futureverse宣布与8家Web3公司合并  
4、阿里云拟于2023年一季度将推出区块链节点服务  
5、奥尼尔：仅是FTX广告的付费代言人，不懂加密货币  
6、美国前总统特朗普发行NFT已全部售罄，交易额近120万美元  
7、俄罗斯央行考虑允许在国内使用加密货币，但仅用于支持对外贸易  
8、NFT收藏者「sevenseason」14枚BAYC NFT尽数被盗，损失约1000 ETH  
9、CryptoQuant公布储备金干净度：OKX位列交易平台第一  
10、Reflexivity创始人：DCG相关Token遭到大规模抛售，投资者怀疑抛压来自DCG  
