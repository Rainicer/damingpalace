---
layout: post
title:  "cryptnews-20220811"
---
1、路透社：Ripple Labs正考虑购买Celsius相关资产  
2、Coinbase新增Near Protocol（NEAR）至路线图资产列表  
3、Bitcoin.com：已集成若干以太坊生态主流ERC-20 Token，将支持存储和兑换服务  
4、美联储埃文斯：预计2023年底联邦基金利率在3.75％-4％范围内  
5、Genesis：Q2发放逾400亿美元新贷款，环比下降9%  
6、美总统拜登：通胀正显示放缓迹象  
7、LongHash Ventures将推出第二只1亿美元规模基金以支持Web3基础设施  
8、美国监管机构提案要求大型对冲基金通过PF表格报告其加密货币风险敞口  
9、元宇宙平台Roblox将于今年推出沉浸式广告系统  
10、Curve Finance：黑客站点已关闭，建议用户使用curve.exchange或确认IP地址.  
