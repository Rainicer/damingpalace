---
layout: post
title:  "cryptnews-20220922"
---
1、以色列加密货币交易平台Bits of Gold获以色列资本市场管理局授予的资本市场许可证  
2、印度提案加强互联网通讯监管，以遏制垃圾邮件与信息欺诈  
3、阿根廷航空公司Flybondi将发行NFT机票，并引入Binance Pay支付  
4、Coinbase已在荷兰央行注册为加密服务提供商  
5、Binance宣布成立全球顾问委员会，包含美英法德等多国政要  
6、Opera旗下加密浏览器将支持Elrond网络  
7、Binance与巴林EazyPay达成合作，推出MENA地区首个合规加密支付服务  
8、中信证券：预计美国经济或将在明年下半年陷入实质性衰退  
9、Apple前全球营销高级副总裁加入去中心化数据管理系统Inery担任首席顾问  
10、OpenSea已支持以太坊Layer2扩容网络Arbitrum  
