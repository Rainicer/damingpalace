---
layout: post
title:  "cryptnews-20230217"
---
1、美SEC已起诉Terraform Labs与Do Kwon策划数十亿美元加密资产证券欺诈  
2、Unstoppable Domains与加密浏览器Opera合作扩展数字身份产品  
3、数字资产行业协会GBBC Digital Finance加入国际证监会组织（IOSCO）  
4、PUMA公布「Super PUMA PFP」发行计划，每枚铸造价格为0.15 ETH  
5、金融合约平台UMA与Snapshot合作推出基于链下投票决策进行链上交易的DAO工具oSnap  
6、美国加州金融保护与创新部发布加密诈骗追踪器  
7、乌兹别克斯坦允许外国企业在当地银行开户并存入加密交易资金，但资金用途受限  
8、WSJ：Bitcoin Core首席维护者已于本周四离职，当前仅5人拥有比特币代码修改权限  
9、挪威当局查获价值约600万美元Ronin Network被盗案中加密货币  
10、WSJ：在美国监管打击下银行正在切断与加密领域的联系  
