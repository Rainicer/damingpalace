---
layout: post
title:  "cryptnews-20221109"
---
1、MoonDAO宇航员狂欢之夜，官宣第二位宇航员来自中国  
2、Arthur Hayes：FTX是加密圈雷曼，当前市场还未见底  
3、Coinbase CEO：FTX事件将导致更加严格的行业监管  
4、Circle联创：FTX事件提醒加密公司不能使用投机Token作为资产负债表基础资产  
5、周星驰发文为其社群征集名称  
6、以太坊自合并以来供应量实现通缩超90枚ETH  
7、Ledger：已暂停Ledger Live中FTX和FTX.US交易功能  
8、彭博社：Ark Invest增持42万股Coinbase股票  
9、知情人士：迪拜拟于年底出台加密监管框架  
10、中东、亚洲和非洲区块链协会MEAACBA在阿布扎比成立  
