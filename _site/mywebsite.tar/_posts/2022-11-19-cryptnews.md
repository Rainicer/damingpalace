---
layout: post
title:  "cryptnews-20221119"
---
1、Tether：将从Solana链上转移10亿枚USDT至以太坊  
2、以太坊信标链验证者数量突破47万，总质押量超1590万枚ETH  
3、中国工商银行发布手机银行8.0版本，可将数字藏品用于头像  
4、V神新文章：使用ZK-SNARK技术改善CEX资产证明，未来或出现加密「受限」CEX  
5、俄罗斯数字资产法修正案旨在允许挖矿、禁止加密货币交易和广告  
6、SuperRare RarePass NFT已售罄并获得超450万美元收入，「RarePass #1」成交价达138 ETH  
7、华尔街投行Jefferies等机构正寻求以低折扣价格获得FTX用户债权  
8、WSJ：SBF曾在FTX此前4.2亿美元B-1轮融资中出售个人持股套现3亿美元  
9、Solana基金会：Solana网络依旧表现良好，将定期更新FTX事件对财务和网络的影响  
10、Ripple正寻求获得爱尔兰虚拟资产服务提供商许可证  
