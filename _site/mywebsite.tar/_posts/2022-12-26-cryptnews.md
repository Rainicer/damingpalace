---
layout: post
title:  "cryptnews-20221226"
---
1、Aave创始人：将于1月初发布GHO公共测试网  
2、隐私区块链Dusk Network将于今年底结束激励测试网的第一阶段  
3、Coinbase：将专注于数字钱包、NFT和云服务以加速Web3采用  
4、Solana生态NFT项目y00ts将于明年第一季度桥接至Polygon  
5、Solana生态NFT项目DeGods将于明年第一季度桥接至以太坊  
6、Octopus Network核心团队40%的成员将离职，团队Token激励无限期暂停  
7、BitKeep：用户资金被盗疑似因APK下载包被黑客劫持  
8、Safe空投Token将于明日结束申领  
9、Coinbase NFT市场将集成Polygon，可使用Coinbase余额购买NFT  
10、数据：加密市场总交易量于昨日降至2019年3月3日以来最低点  
