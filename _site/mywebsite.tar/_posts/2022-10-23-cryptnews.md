---
layout: post
title:  "cryptnews-20221023"
---
1、瑞银：美联储或在2023年年中停止量化紧缩  
2、Compound将提高cCOMP借款上限，并更换cCOMP和cUNI利率模型  
3、Messari：过半数以太坊验证者使用遵守OFAC规定的中继  
4、Aptos链上交易量突破900万笔  
5、分析师猜测Justin Sun或退出DeFi转投美国政府债券  
6、APT短时突破9.85美元，24小时涨幅31.46%  
7、Azuki Golden Skateboard拍卖总额超1900 ETH  
8、今年第三季度区块链和加密公司融资额较峰值减少71%  
9、加密交易平台BitGoldEX完成A轮融资，BAIF Group参投  
10、DeFi总锁仓量在过去六个月减少67%  
