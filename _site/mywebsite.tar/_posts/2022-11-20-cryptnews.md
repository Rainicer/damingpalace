---
layout: post
title:  "cryptnews-20221120"
---
1、美联储博斯蒂克：准备在12月会议上「放弃」加息75个基点  
2、35,000枚ETH从Coinbase转入未知钱包  
3、LayerZero已上线Metis的Goerli测试网  
4、Ripple CEO：考虑购买FTX部分资产  
5、CZ：Binance将实施V神新想法并为行业开源  
6、美国法院称45亿美元Bitfinex被盗资金洗钱案涉及机密信息  
7、加勒比海地区岛国圣尼拟于2023年将BCH定为法定货币  
8、数据：zkSync桥接存储总价值突破18万枚ETH  
9、过去两周USDC市值已反弹近28亿美元  
10、过去一小时FTX黑客已抛售1.7万枚ETH  
