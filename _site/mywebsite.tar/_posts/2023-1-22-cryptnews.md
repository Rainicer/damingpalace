---
layout: post
title:  "cryptnews-20230122"
---
1、The Sandbox将推出《流浪地球》中国农历新年主题NFT系列  
2、Stargate社区就以市场价格向一家族办公室出售价值200万美元的STG进行投票  
3、Mars Protocol计划于1月31日上线主网，并向快照地址发放空投  
4、以太坊Layer2网络总锁仓量突破50亿美元，近7日上涨7.58%  
5、WSJ：Signature Bank与Silvergate向美国联邦住房贷款银行贷款总额超100亿美元  
6、以太坊链上NFT销售总额突破350亿美元  
7、Binance：合作伙伴Signature Bank将于2月起不再接受10万美元以下的加密货币交易  
8、Genesis前高管在Genesis破产前已为其新对冲基金筹集数百万美元  
9、Memeland上线软质押功能QUESTING V1，持有者可赢得奖品  
10、BAYC铸造型游戏Dookey Dash已有3277名玩家参与购买Buff，共带来超5.8万枚APE的收入  
