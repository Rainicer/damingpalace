---
layout: post
title:  "cryptnews-20221204"
---
1、Aave创始人：Aave社区正准备在以太坊上部署Aave V3  
2、美国纽约州拟禁止退休金用于投资加密货币  
3、数据：以太坊域名服务ENS注册总量突破280万  
4、Reddit Collectible Avatar总量突破400万  
5、传奇球星马斯切拉诺将与SaaSGo在纽约举办限量版世界杯NFT发布会  
6、火狐浏览器开发公司Mozilla收购Active Replica，拟拓展Web3和元宇宙市场  
7、外媒：AAX尼日利亚用户冲入当地办公室殴打员工索要被冻资金  
8、Binance Custody在新加坡推出机构托管服务  
9、马斯克：推特致力于让meme币交易变得更容易  
10、11月DEX交易额重返1000亿美元上方，系过去6个月以来首次  
