---
layout: post
title:  "cryptnews-20221216"
---
1、审计机构Mazars已暂停为Binance等加密货币客户提供服务  
2、韩国游戏巨头Wemade链游平台WEMIX PLAY推出游戏Token兑换服务  
3、《金融时报》：多家对冲基金加大做空加密矿企力度  
4、以太坊域名服务ENS推出官方商店「ENS Merch Store」  
5、Crypto.com获得由巴西央行颁发的支付机构许可证  
6、纽约州金融服务局：银行从事虚拟货币相关活动需获得事先批准  
7、NFT基础设施平台Bonfire完成620万美元种子轮融资，Coinbase Ventures等参投  
8、Web3基础设施公司Blocknative完成1500万美元A-1轮融资，Blockchain Capital等领投  
9、Magic Eden已集成至Polygon  
10、美众议员敦促美国财长发布更明确的数字资产报告规则  
