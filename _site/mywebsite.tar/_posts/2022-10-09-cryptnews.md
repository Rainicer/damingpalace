---
layout: post
title:  "cryptnews-20221009"
---
1、上海海事法院推出《区块链证据审查指南》  
2、OpenSea首席财务官Brian Roberts宣布已辞职  
3、大理Hacker House活动将于10月10日举办，包含Move和以太坊合约开发课程  
4、Cosmos联创：BNB Chain攻击事件中黑客通过RangeProof伪造Merkle证明  
5、央行牵头多部门联合执法，13款涉虚拟货币交易APP被下架  
6、FTX等25家加密公司入围CB Insights本年度金融科技250强榜单  
7、Messari报告：波卡Q3营收下降47%，活跃地址下降40%  
8、Nethermind：Uniswap V3合约已完成Cairo转译  
9、Glassnode：近期比特币矿工抛售或主要来自币印矿池  
10、Synthetix创始人：当前DeFi治理比一年前更糟，社区投票需直接与多重签名联系起来  
