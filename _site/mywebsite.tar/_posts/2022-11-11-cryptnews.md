---
layout: post
title:  "cryptnews-20221111"
---
1、摩根大通：加密货币行业正在进行新一轮去杠杆化  
2、Binance公布资产储备明细：共持有47.5万枚BTC、480万枚ETH和5800万枚BNB  
3、美SEC主席：投资者在加密货币领域需要得到更好的保护  
4、加密做市商GSR：将承担FTX倒闭造成的客户损失  
5、Ark Invest再次购入23.8万股Coinbase股票  
6、Aptos与Google Cloud达成合作，将启动加速器计划  
7、石油、天然气巨头壳牌计划为比特币矿机提供液冷解决方案  
8、白宫：已了解FTX暴雷事件，将继续关注局势  
9、福布斯：红杉资本、淡马锡和Paradigm将是FTX事件中损失最大的三家投资机构  
10、Justin Sun：已经准备好为FTX提供数十亿美元的援助  
