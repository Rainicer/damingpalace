---
layout: post
title:  "cryptnews-20230119"
---
1、韩国检察官起诉20人因加密货币「泡菜溢价」非法获利1.7亿美元  
2、Polygon发布2022年终洞察报告，四季度活跃钱包数量同比增加115%  
3、欧易OKX发布第三次储备金证明报告，储备金总价值增长16.64%达75亿美元  
4、The Sandbox与《北斗神拳》合作，将在元宇宙推出游戏「世纪末之地」  
5、Binance2022年年终报告：日均交易额650亿美元，投资超5亿美元支持Web3和区块链创新  
6、去中心化索引协议The Graph新增支持Arbitrum、Optimism、Avalanche和Celo  
7、Circle和Uniswap联合研究：DeFi可解决外汇交易风险问题，每年可节省300亿美元跨境汇款成本  
8、比特币连续14个交易日上涨，创自2017年3月以来最长记录  
9、Linux基金会成立开放元宇宙基金会，将协调开发元宇宙开源软件和标准  
10、Aave已在Goerli、Mumbai、Optimism和Arbitrum测试网上部署V3.0.1版本  
