---
layout: post
title:  "cryptnews-20221018"
---
1、Ripple正测试兼容EVM的XRP Ledger侧链，拟于2023年正式推出  
2、SBI和Securitize将于新加坡合作发行Token化债券  
3、数字艺术家Beeple正打造线下NFT工作室，旨在将NFT带入现实  
4、Dapper Labs联创携CryptoKitties与好莱坞顶级经纪公司WME签约  
5、法国将于明年探索加密货币的税务处理方法  
6、Ledger：已对NFT通行证持有者快照，将于10月19日进行空投  
7、Polygon公布生态进展：dApp数量达5.3万，月活开发者超1.3万  
8、dYdX与法币网关Banxa达成合作，允许用户直接购买USDC  
9、公链Aptos主网「Aptos Autumn」已正式启动  
10、福布斯：SEC已收到超过1.1万封支持Grayscale现货BTC ETF的信函  
