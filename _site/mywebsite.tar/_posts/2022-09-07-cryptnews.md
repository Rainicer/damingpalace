---
layout: post
title:  "cryptnews-20220907"
---
1、加密银行Signature Bank：加密货币流出总额已高达42.7亿美元  
2、泰国SEC向警方指控Zipmex及其CEO未提交相关数据  
3、BendDAO将在以太坊主网合并前3小时暂停一切功能  
4、加拿大互联网服务提供商easyDNS已支持原生ENS域名服务  
5、数据：比特币闪电网络容量突破4700枚BTC，创历史新高  
6、SPACE ID：.bnb域名阶段性注册推迟至下周  
7、Binance：目前暂无将USDT自动转换为BUSD的计划  
8、Web3能源初创公司Tesseract完成7800万美元融资，Balderton等参投  
9、韩国当红歌星李洪基入驻Muverse音乐平台  
10、澳大利亚监管机构Blockchain Australia任命前贝莱德董事为新任首席执行官  
