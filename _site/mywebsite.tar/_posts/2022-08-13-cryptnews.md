---
layout: post
title:  "cryptnews-20220813"
---
1、菲律宾联合银行将在其移动端应用程序内提供加密货币兑换功能  
2、神鱼：个人DeFi挖矿地址因收到Tornado相关地址转账遭Aave封禁  
3、Bitcoin.com：已集成若干以太坊生态主流ERC-20 Token，将支持存储和兑换服务  
4、Slope宣布推迟公布其外部审计结果  
5、Pocket Network回应：协议层面不限制任何App，未来开发者可拥有自己的数据访问通道  
6、以太坊触及2000美元，24小时涨幅4.86%  
7、Aave前端或开始封禁曾参与Tornado Cash挖矿的地址  
8、Pocket Network宣布将阻止Tornado Cash相关被制裁地址与其交互  
9、基于Polygon的电竞元宇宙平台Yesports推出NFT市场  
10、Gitcoin将于9月7日至22日进行第15轮捐赠活动  
