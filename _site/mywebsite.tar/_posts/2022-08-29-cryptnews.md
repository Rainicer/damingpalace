---
layout: post
title:  "cryptnews-20220829"
---
1、NFT项目DigiDaigaku 24小时交易额涨幅近400%，地板价暂报7.5 ETH  
2、金融分析师：美联储资产距其峰值仅降低1.3%，缩表进程并不简单  
3、埃米纳姆和Snoop Dogg在Otherside为MTV音乐录影带奖颁奖典礼表演知名单曲  
4、Acala：已定位到剩余5200万枚异常增发aUSD  
5、Shopify或将集成Web3工具包Thirdweb，以方便用户创建NFT  
6、Jack Dorsey旗下支付公司Afterpay终止与澳大利亚西太平洋银行的合作  
7、Binance在喀麦隆开设非洲法语系国家首个加密教育中心  
8、Etherscan Optimism Goerli浏览器现已上线  
9、CZ：不确定Ava Labs恶意竞争的消息是否属实，Binance甚至不是其竞争对手  
10、数据：比特币市值被腾讯反超  
