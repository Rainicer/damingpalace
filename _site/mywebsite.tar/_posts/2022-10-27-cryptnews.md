---
layout: post
title:  "cryptnews-20221027"
---
1、挪威官方将在Decentraland设立元宇宙税务局和办事处  
2、越南总理呼吁政府监管加密货币  
3、数据：StarkNet桥接存储TVL突破2000枚ETH，月增长超100%  
4、《彭博商业周刊》将于10月31日出版专刊「The Crypto Story」  
5、数据：加密市场总市值重回1万亿美元，24小时涨幅2.7%  
6、Etherscan推出Arbitrum Nova区块浏览器  
7、V神：2023年以太坊首要任务是解决可扩展性  
8、CZ：哈萨克斯坦央行将在BNB Chain上集成其CBDC  
9、《自然医学》杂志论文披露以太坊区块链正被用于全球抗击癌症  
10、Discord拓展应用插件Collab.Land已集成Ronin Network  
