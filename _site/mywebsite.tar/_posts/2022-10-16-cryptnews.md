---
layout: post
title:  "cryptnews-20221016"
---
1、OpenSea：暂时取消在主页显示Solana热门NFT  
2、以太坊JavaScript库Ethers.js推出Shanghai升级前的测试网Shandong  
3、香港财政司司长：香港金融科技周将发布虚拟资产政策宣言  
4、印度计划在担任G20轮值主席国期间制定加密监管框架  
5、加拿大央行：本地居民持有比特币的比例在2021年已增至13.1%  
6、金融稳定委员会 (FSB) 发布国际加密资产监管框架  
7、香港财政司司长：推动香港发展成国际虚拟资产中心  
8、彭博社：韩国计划2024年向公众提供基于区块链的数字身份  
9、以太坊客户端Nimbus发布v22.10.1，新增支持官方轻客户端 REST API  
10、StarkWare总裁：StarkWare原生Token将在10月上链  
