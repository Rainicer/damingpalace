---
layout: post
title:  "cryptnews-20220823"
---
1、DeFi一站式平台Zerion将对以太坊主网交易收费，创世NFT持有者仍可免费交易  
2、Web3激励性健康保险技术平台Growfitter完成50万美元pre-A轮融资，Venture Catalysts领投  
3、去中心化社交ID平台Quivr完成355万美元种子轮融资，腾讯联创Jason Zeng参投  
4、DeFi Kingdoms将完全脱离Harmony，并在Klaytn上推出  
5、德国联邦金融监管局：加密资产不受存款保险和投资者赔偿保护  
6、a16z合伙人Chris Dixon：加密市场低迷给风投公司更多投资机会，希望创造一个更好的互联网  
7、伊朗近期已查获超9400台非法加密挖矿设备  
8、火币科技旗下子公司Hbit Technologies获加拿大货币服务业务（MSB）牌照  
9、sudoswap NFT交易数量突破10万枚  
10、Telegram创始人宣布拟推链上用户名交易市场后TON上涨近20%  
