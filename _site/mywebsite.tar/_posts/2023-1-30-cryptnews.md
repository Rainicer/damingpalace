---
layout: post
title:  "cryptnews-20230130"
---
1、Aleph Zero赢得第38轮波卡平行链插槽拍卖  
2、加密安全初创公司Hypernative完成900万美元融资，boldstart ventures领投  
3、英超联赛与Sorare签订许可协议，允许Sorare用户收集、交易球员数字卡牌  
4、菲律宾证券监管机构就加密法规草案征求意见  
5、长寿研究社区VitaDAO完成410万美元融资，辉瑞旗下Pfizer Ventures参投  
6、Arbitrum网络总锁仓量超越Polygon，位列全网锁仓量排行榜第四  
7、深圳安排发放累计1亿元餐饮数字人民币红包  
8、Justin Sun：Huobi不会向税务机关共享客户信息，除非遵循国际司法协助程序  
9、哈萨克斯坦议会已批准监管加密货币挖矿和交易的新立法  
10、菲律宾证交会提交涵盖数字产品和加密货币监管的新草案  
