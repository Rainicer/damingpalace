---
layout: post
title:  "cryptnews-20230106"
---
1、「变异猿」MAYC地板价升至19.6 ETH，创近7个月币本位新高  
2、印度央行行长：央行数字货币是各国央行可以合作的领域  
3、MetaMask：已从移动聚合器中移除Wyre，请停止使用Wyre  
4、数字收藏品公司Candy Digital完成A1轮融资，Galaxy等领投  
5、法国央行行长敦促对加密公司实施强制许可制度  
6、微软首席战略官：谈论客户体验时，元宇宙是必须品  
7、电商巨头Shopify：已支持所有线上商家直接出售和铸造Avalanche链上NFT  
8、ChatGPT母公司OpenAI拟以290亿美元估值通过收购要约形式出售股票  
9、三箭资本联合清算人通过Twitter向两名创始人发送传票  
10、DCG将关闭其资管子公司HQ Digital  
