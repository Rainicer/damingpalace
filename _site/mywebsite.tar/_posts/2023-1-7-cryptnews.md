---
layout: post
title:  "cryptnews-20230107"
---
1、Memeland船长NFT空投已完成，OpenSea上地板价暂报7.2ETH  
2、Glassnode：Deribit上BTC永续期货合约未平仓合约创两年新低  
3、Opensea宣布支持Arbitrum Nova  
4、OpenSea官网出现BUG，CryptoPunks 24小时交易量错误显示为「10亿ETH」  
5、知情人士：美联邦法院正针对DCG的内部交易问题展开调查  
6、混币器Helix创始人弟弟承认曾从美国国税局窃取超过712枚比特币  
7、支付巨头万事达卡宣布联合Polygon推出Web3艺术家孵化器  
8、Binance宣布加入认证制裁专家协会  
9、Moonbirds创始人Kevin Rose与好莱坞大型经纪公司UTA签约  
10、NFT交易市场SuperRare开发商将裁员30%  
