---
layout: post
title:  "cryptnews-20230114"
---
1、Tether：2022年总交收量达18.2万亿美元  
2、Osprey Funds CEO致信DCG以寻求管理其GBTC信托，可削减约75%管理费  
3、2023年迄今表现最好的14只股票ETF均与加密货币相关  
4、Dune Analytics已集成比特币链上数据  
5、Polygon正对ZK Rollups技术进行性能测试  
6、ConsenSys将为MetaMask添加以太坊质押功能  
7、Justin Sun：有意愿斥资10亿美元购买DCG资产  
8、Celsius：将于未来几日内进行平台维护  
9、比特币日线RSI进入超买区间，处于近2年内最高水平位置  
10、主流元宇宙、游戏项目Token出现较大幅度上涨，MANA涨超34%  
