---
layout: post
title:  "cryptnews-20230125"
---
1、Robinhood确认推特账号遭黑客入侵并已展开调查  
2、Doodles：将在Flow区块链上发布Doodles 2  
3、Circle发布跨链传输协议开发文档：USDC的跨链销毁和铸造必须获得「签名证明」  
4、元宇宙电商Emperia完成1000万美元A轮融资，Base10 Partners领投  
5、纽约法院已授权Flare向合格Celsius账户空投FLR Token  
6、加密货币衍生品交易平台Deribit选择Eventus作为交易监控平台  
7、欧洲议会ECON委员会投票通过银行规则改革，要求银行披露对加密资产和加密资产服务敞口  
8、美国亚利桑那州拟立法让选民决定加密货币是否成为免税财产  
9、保时捷NFT项目宣布减少供应，将于1月25日19时停止铸造  
10、Blockstream完成1.25亿美元融资以扩大挖矿业务  
