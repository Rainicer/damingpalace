---
layout: post
title:  "cryptnews-20221108"
---
1、a16z Crypto推出以太坊轻客户端Helios，基于Rust语言编写  
2、以太坊联创Di Iorio公布新项目Andiami，将推广区块链计算机  
3、俄罗斯央行拟将加密资产整合至该国金融系统中  
4、窃取超5万枚比特币的犯罪嫌疑人在纽约南区法院认罪  
5、以太坊开发者呼吁DApp开发者从Goerli测试网改用Sepolia测试网  
6、中国移动香港打造「元宇宙数字空间」，推出NFT自由集市  
7、OKGroup创始人徐明星：若BNB市值超过BTC，加密行业将失败  
8、CoinW亮相第13届环球足球奖，并成为其首个加密领域合作机构  
9、华为云联合新加坡IMDA启动Web3孵化器计划「Spark」  
10、LINE子公司LINE NEXT在旗下NFT平台DOSI上推出支持以太坊的C2C服务  
