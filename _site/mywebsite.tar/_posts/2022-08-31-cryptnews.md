---
layout: post
title:  "cryptnews-20220831"
---
1、Sei Labs完成500万美元种子轮融资，Multicoin Capital领投  
2、派盾：AscendEX黑客地址再次转移150万枚DAI  
3、以太坊最大矿池Ethermine为用户推出新质押服务  
4、DigiDaigaku持有者将于9月2日免费获得空投  
5、慢雾：匿名诈骗者利用网络钓鱼窃取包括Moonbird和Azukki在内的114枚NFT  
6、Arbitrum One主网将于今日22:30迁移至Nitro，预计该过程需要2至4小时  
7、彭博：加密市场的暴跌导致了劳力士、百达斐丽等奢华腕表市场的崩溃  
8、Curve原生Stablecoin crvUSD或将于下月推出  
9、Web3智能消息平台Dialect宣布拓展至Aptos  
10、以太坊上涨触及1600美元，24小时涨幅4.3%  
