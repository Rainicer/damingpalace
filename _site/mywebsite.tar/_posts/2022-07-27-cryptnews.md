---
layout: post
title:  "cryptnews-20220727"
---
1、Polygon发布Q2数据：独立地址数量增长12%至534万个，网络收入为556万美元  
2、Interplay计划为其新基金筹集1000万美元，重点投资Web3等领域  
3、Web3社区管理解决方案服务提供商ILUMA完成250万美元融资，Acrew Capital领投  
4、Audacity推出6000万美元专注于Web3创作者经济的媒体科技新基金  
5、Blockchain.com出现用户数据泄露情况，用户近期或将收到一系列假冒官方邮件  
6、NFT租赁基础设施reNFT完成500万美元融资，OpenSea和The Sandbox等参投  
7、Kadena公布其「1 亿美元赠款计划」首批9个入选项目  
8、前Instagram Shopping创始人兼产品总监加入Gemini任产品副总裁  
9、NFT艺术品平台Artfi以1亿美元估值完成326万美元融资  
10、通用市场协议Root Protocol完成900万美元融资，Road Capital领投  
