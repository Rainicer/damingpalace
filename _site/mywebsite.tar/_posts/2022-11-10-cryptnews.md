---
layout: post
title:  "cryptnews-20221110"
---
1、传奇球星梅西入股数字足球NFT收藏平台Sorare，并担任品牌大使  
2、DeBank推出Time Machine功能，可回顾历史投资组合详细信息  
3、MetaMask推出跨链桥集成功能  
4、Web3医疗大数据协议DeHealth已集成Polygon  
5、SEC已于数月前开始调查FTX US及其加密借贷活动  
6、美SEC主席：部分加密货币法案破坏了证券法规定  
7、美国司法部正对FTX进行调查  
8、StarkNet基金会成立，将持有50.1%StarkNet Token  
9、Justin Sun：正与FTX一起制定解决方案以支持FTX上Tron系Token  
10、Chainlink：支持喂价的多个数据提供商已移除FTX数据源  
