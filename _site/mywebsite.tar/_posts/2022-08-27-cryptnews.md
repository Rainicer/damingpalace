---
layout: post
title:  "cryptnews-20220827"
---
1、Web3社交娱乐平台Pixie完成新一轮战略融资，KuCoin Ventures参投  
2、比特币短时跌破20,000美元，24小时跌幅6.33%  
3、王峰回应NFT版税之争，并计划在ELE DAO中发起第一份提议  
4、Binance因配合执法要求冻结一Tezos贡献者企业账户超百万美元  
5、Meta社交VR平台Horizon副总裁Vivek Sharma即将离职  
6、Voyager将收购投标申请截止时间延长到9月6日  
7、Axie Infinity将于今日11：30部署平衡补丁并停机  
8、Arbitrum One完成影子分叉迁移，预计8月31日正式迁移时需2至4小时  
9、Triple A报告：全球加密货币持有者突破3亿，美、印排名前2  
10、美国银行：在合并完成之前ETH价格上涨势头可能会消退  
