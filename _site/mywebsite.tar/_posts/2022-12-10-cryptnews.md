---
layout: post
title:  "cryptnews-20221210"
---
1、印度板球明星Shikhar Dhawan推出7500万美元科技基金，拟将Web3引入体育领域  
2、金融科技公司Symbiont.io申请破产保护，曾与SWIFT合作试点区块链项目  
3、去中心化内容发布平台Mirror宣布支持NFT嵌入  
4、Coinbase CEO：加密信任危机和监管的进一步发展或将促进USDC的使用  
5、内蒙古警方破获特大虚拟货币洗钱案，涉案高达120亿元  
6、欧盟：成员国超1000欧元的加密货币交易将受到VASP尽职调查  
7、持币大于10 ETH地址数量达343,662个，创历史新高  
8、巴哈马律师向美国特拉华州破产法官申请访问FTX客户数据库  
9、Zhu Su：The Block一直由SBF全资拥有，并负责把控新闻编辑方向  
10、加密基金Variant Fund：已购入「一些Nouns NFT」  
