---
layout: post
title:  "cryptnews-20230213"
---
1、Aave社区发起旨在冻结Aave V2以太坊市场上BUSD的提案  
2、Paxos宣布结束与Binance在稳定币BUSD上的合作关系，现有BUSD在2024年2月前仍得到充分支持并可赎回  
3、Binance发言人证实Paxos被告知停止发行新BUSD Token  
4、纽约金融服务部命令Paxos停止发行新BUSD Token  
5、Rocket Pool社区将自身ETH质押市场份额限制在22%的提案已获投票通过  
6、Ankr成为Secret Network首批企业级RPC提供商之一  
7、韩国法院批准延长Bithumb实际所有者姜钟贤的拘留期限至2月20日  
8、Web3社交协议Atem Network：官方Discord正被入侵，用户不要相信任何私信  
9、彭博社：港金管局计划通过首次Token化绿色债券发行筹集8亿港元  
10、V神昨日再向土耳其捐款地址捐赠50枚ETH  
