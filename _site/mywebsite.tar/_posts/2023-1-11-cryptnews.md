---
layout: post
title:  "cryptnews-20230111"
---
1、高盛宣布旗下数字资产平台GS DAP已正式上线  
2、Coinbase前产品经理的兄弟因内幕交易被判10个月有期徒刑  
3、FTX股东名单更新，包含PayPal联创Peter Thiel、NFL球星Tom Brady等知名人士  
4、美参议员呼吁FTX破产法官任命一名独立审查员  
5、Crypto.com将针对加拿大用户下架USDT交易对  
6、Optimism Goerli测试网将于1月13日升级至Bedrock架构，可减少约20% Gas费用  
7、DigiDaigaku母公司引入可编程版税合约  
8、保时捷中国将发行「911-梦想家」系列数字藏品  
9、Twitter正开发Coins购买界面和菜单项，将使用Stripe处理法币支付  
10、DCG CEO发布《致股东信》：与子公司不存在现金资产混用的问题  
