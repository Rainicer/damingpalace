---
layout: post
title:  "cryptnews-20230129"
---
1、MakerDAO发布新提案，拟提高Compound D3M债务上限  
2、BAYC铸造游戏门票Sewer Pass持有者将有权参与下一次迭代「The Summoning」  
3、Art Blocks宣布新增支持二级交易购买功能并执行版税  
4、数据显示加密巨鲸正集中关注LTC、MATIC、Aave和DYDX  
5、比特币挖矿难度上调4.68%至39.35 T，续创历史新高  
6、Arbitrum生态永续合约交易平台Vest Exchange完成种子轮融资  
7、Azuki社交账户黑客已将窃取资金转移至TornadoCash  
8、CZ：每个人对元宇宙都有不同的概念  
9、USDT稳定币市场主导地位升至49.24%，创2021年11月以来最高水平  
10、ZigZag创始人提议交易额排行前10万名用户可获取300 ZZ空投奖励  
