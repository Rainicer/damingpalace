---
layout: post
title:  "cryptnews-20221213"
---
1、加拿大证券管理局将对加密交易平台实施更严格的监管框架  
2、安永：在深圳开设亚太技术实验室「APAC Tech Lab」，拟利用区块链和Web3等新兴技术力量  
3、泰国证券交易委员会：将对加密资产设定更严格的监管规则  
4、数据：Polygon单周NFT用户量突破24万，创历史新高  
5、数据：约13%的美国人购买过加密货币  
6、《纽约时报》：SBF被指控电汇欺诈、证券欺诈和洗钱等罪名  
7、Web3元宇宙初创公司MetaVersusWorld完成200万美元种子轮融资，Alphabit Digital Currency Fund等参投  
8、库里因推广「无聊猿」BAYC遭投资者起诉  
9、ENS DAO正在进行明年一、二季度工作组管理员选举，投票将于12月15日结束  
10、Solana EVM兼容方案Neon已推迟发布  
