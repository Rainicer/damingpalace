---
layout: post
title:  "cryptnews-20221026"
---
1、The Graph联创将推出信息图谱协议和对应Web3浏览器  
2、诺基亚CTO：本世纪下半叶元宇宙将取代智能手机  
3、数字资产平台CHINTAI获新加坡运营证券数字资产市场相关执照  
4、加密托管平台Zodia Custody推出加密所有权证明产品  
5、贝莱德旗下Global Infrastructure Fund IV已募资45亿美元，将投资数字基础设施等领域  
6、蒂芙尼将于10月26日向NFTiff持有者展示CryptoPunks定制吊坠  
7、支付巨头PayPal提交NFT和元宇宙商标申请  
8、马斯克：计划在周五完成收购推特交易  
9、土耳其央行计划明年推出 CBDC  
10、全球结算银行平台Arf完成1300万美元种子轮融资，Circle Ventures、Hard Yaka等参投  
