---
layout: post
title:  "cryptnews-20220818"
---
1、跨链支付网络cBridge前端遭到DNS劫持攻击  
2、Web3数字娱乐公司Rusk Media完成950万美元A轮融资，DAOL Investment和Audacity Ventures领投  
3、美联储会议纪要：「几乎没有证据」表明通胀压力正在减弱  
4、美联储会议纪要：加息步伐将在某个时候放缓  
5、链游生态系统MatchboxDAO完成750万美元融资，Starkware等参投  
6、NFT碎片化协议Tessera完成2000万美元A轮融资，Paradigm领投  
7、摩根大通：Coinbase将受益于以太坊合并  
8、EOSIO区块链协议已正式更名为Antelope，实现真正独立发展以建立广泛生态  
9、音乐NFT平台MetaBeat完成战略融资，KuCoin Labs等参投  
10、Axie Infinity侧链Ronin宣布添加Nansen等三个新验证节点  
