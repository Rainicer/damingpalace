---
layout: post
title:  "cryptnews-20220804"
---
1、派盾：V神相关钱包地址出售25万亿枚SHIT，约合3.3万美元  
2、美弗吉尼亚州费尔法克斯县养老基金获董事会批准以投资DeFi协议  
3、泰国暹罗银行金融科技投资部门SCB 10X任命新CEO领导加密投资  
4、Voice Street上线BitCoke，Token VST涨幅超1200%  
5、GameStop正在招聘NFT内容审核负责人  
6、比特币跌破23,000美元，24小时跌幅0.15%  
7、Coinbase将上线Stargate Finance（STG）和League of Kingdoms Area（LOKA）  
8、报告：今年以来跨链桥黑客事件被盗资金总额达20亿美元  
9、M2E应用SNKRZ获韩国游戏开发商WeMade战略投资  
10、Pando Asset已在瑞士证券交易平台发行加密货币ETP  
