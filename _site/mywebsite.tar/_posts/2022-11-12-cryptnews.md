---
layout: post
title:  "cryptnews-20221112"
---
1、加州监管机构暂时吊销BlockFi贷款许可证，正对FTX展开调查  
2、FTX在Telegram称遭黑客攻击，资产已被窃取  
3、SignalPlus联合Bybit举办的全球加密期权交易大赛将于11月14日18时正式开启  
4、Kraken高管：已确认FTX资金异动用户的身份  
5、由FTX或Alameda在Solana上发行的soBTC已不可赎回，交易价格暴跌  
6、路透社：SBF在FTX系统中内置「后门」并借此转移数十亿美元资金  
7、Bitfinex储备金证明：135个冷、热钱包地址总计持有超20万枚BTC和超122万枚ETH  
8、FTX相关地址已窃取价值1.89亿美元的ETH和DAI  
9、FTX相关地址通过DEX出售从FTX转移的部分资产  
10、Justin Sun：Huobi、Poloniex、USDD对FTX无风险敞口  
