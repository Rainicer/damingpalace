---
layout: post
title:  "cryptnews-20220731"
---
1、娱乐巨头派拉蒙影业公司将发行NFT  
2、以太坊Layer 2总锁仓量突破50亿美元，7日涨幅15.64%  
3、路透社：马斯克就440亿美元的交易反诉Twitter  
4、Element Black宣布与公关及品牌推广公司Chill Chi PR达成合作  
5、大学生全球线上马拉松THUBA DAO Summer Hack正式启动  
6、YGG发布首年回顾报告：打金成员已获得超1000万美元收入  
7、Axie Infinity侧链Ronin Network新增YGG等4个验证节点  
8、Glassnode：超10年未活跃的比特币供应量接近250万枚，创历史新高  
9、比特币矿企Bitfarms 为「The Bunker」矿场增加18兆瓦容量，算力增加200 PH/s  
10、Juno Network发布v.9.0.0版本，已恢复出块  
