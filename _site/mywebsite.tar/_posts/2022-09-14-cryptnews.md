---
layout: post
title:  "cryptnews-20220914"
---
1、俄罗斯最早可能于2023年开始接受加密货币进行跨境支付  
2、彭博社：印度加密交易平台自征收1% TDS税以来日交易量下降超90%  
3、云加速服务商Cloudflare宣布支持以太坊合并，并上线支持Görli和Sepolia的测试网网关  
4、欧易OKX更新以太坊合并升级处理方案，若以太坊分叉将按比例空投分叉币  
5、Lido或已完成向Dragonfly Capital出售1000万枚LDO的交易  
6、Huobi成为继Binance、FTX后第三家与韩国釜山签约的全球加密交易平台  
7、韩国法院对Terra创始人Do Kwon发出逮捕令  
8、俄加密初创公司InDeFi计划推出基于DAI模型的卢布锚定Stablecoin  
9、CZ：希望欧盟MiCA监管框架成为「全球标准」，尽管它对Stablecoin「有些严格」  
10、Coinbase Cloud推出Polygon网络MATIC质押服务  
