---
layout: post
title:  "cryptnews-20221219"
---
1、推特将禁止用户免费推广Facebook、Instagram等社交媒体平台  
2、Binance将支持阿塞拜疆央行建立加密资产监管框架  
3、经济日报：港交所上市虚拟资产ETF，审慎发展虚拟资产迈出关键步伐  
4、港交所加密货币ETF周一开盘后跌破发行价，南方东英以太币期货ETF跌幅超6.7%  
5、Binance Pay与Pyypl合作，支持用户使用加密货币充值数字钱包  
6、Web3智能合约钱包UniPass Wallet上线Scroll测试网  
7、CryptoQuant：Binance储备金干净度为89%，Huobi储备金干净度为56.7%  
8、OneCoin联创就电汇欺诈、共谋洗钱等多项指控认罪，最高面临60年监禁  
9、俄检察官：调查机构应被允许设立加密钱包和交易平台访问权限  
10、欧洲央行副行长：欧洲央行将继续加息50个基点  
