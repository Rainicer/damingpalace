---
layout: post
title:  "cryptnews-20221025"
---
1、香港投资推广署主管：港府高度关注证券型Token，相关立法预计明年一季度完成  
2、NBA纽约尼克斯队与Coinbase合作发行NFT系列「New York Forever」  
3、以太坊链上聚合收益协议Zunami推出原生Stablecoin UZD  
4、以色列特拉维夫证券交易平台TASE计划涉足加密货币并创建数字资产平台  
5、借贷市场QuickSwap Lend因闪电贷攻击损失22万美元，将暂时关闭  
6、Fireblocks推出数字资产支付引擎，金融科技巨头FIS成为其合作伙伴  
7、Web3内容发布平台Paragraph完成170万美元融资，Lemniscap领投，FTX Ventures和Binance Labs等参投  
8、PancakeSwap与Aptos集成，将部署其原生Token CAKE  
9、澳大利亚加密交易平台LocalCryptos将结束运营、退出市场  
10、英国新任首相苏纳克曾于4月提议将英国打造成加密友好的技术中心  
