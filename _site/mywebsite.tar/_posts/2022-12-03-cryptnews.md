---
layout: post
title:  "cryptnews-20221203"
---
1、Coinbase于2028年到期的债券价格已跌至59美分，过去一个月跌幅达10%  
2、三箭清算公司Teneo已获得三箭部分资产控制权  
3、纽约州共同退休基金和俄亥俄州教师退休系统均因FTX破产受损  
4、韩国法院驳回对Terra联合创始人Daniel Shin的逮捕令  
5、美众议院金融服务委员会主席：SBF仍未回复确认是否参加12月13日的听证会  
6、Coinbase暂停BAYC三部曲短片「Degen Trilogy」的拍摄计划  
7、Ankr：将动用储备金赔偿aBNBc流动性提供者  
8、彭博社：FTX旗下衍生品交易平台LedgerX正挂牌出售，Blockchain.com和Gemini或为潜在收购方  
9、MetaMask联创：已准备好放弃苹果生态系统，将和Coinbase一起反抗苹果税  
10、外媒：资管巨头Apollo计划在雅虎财经上提供提供零售加密交易  
