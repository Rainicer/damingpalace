---
layout: post
title:  "cryptnews-20230210"
---
1、慢雾：Monkey Drainer黑客组织通过网络钓鱼获利1297.2万美元，共有7059枚NFT被盗  
2、微软已解散工业元宇宙团队，全部100名员工遭解雇  
3、比尔·盖茨：ChatGPT「将改变我们的世界」，重要性不亚于发明互联网  
4、派盾：V神向土耳其地震捐款地址捐赠1 ETH  
5、Bitzlato联创在莫斯科短暂拘留审问后获释  
6、Twitter开发者版本App更新「Coins」功能及用法简介  
7、以太坊客户端Prysm开发更新：已实现并审查所有支持Capella升级中提款的核心功能  
8、Justin Sun：Huobi将继续扩大其在香港的业务  
9、稳定币兑换协议Curve现已集成欧易Web3钱包  
10、Sui开发公司Mysten Labs与腾讯云达成合作  
