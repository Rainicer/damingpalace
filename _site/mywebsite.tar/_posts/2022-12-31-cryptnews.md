---
layout: post
title:  "cryptnews-20221231"
---
1、贝莱德成为Core Scientific最大债权人之一，持有3790万美元可转换债券  
2、SushiSwap CEO发布新Token经济学提案，旨在激励流动性并促进去中心化  
3、Pi Network：未授权任何加密货币交易平台上线Pi  
4、「BIT回购计划」提案通过，将在50天内累计回购1亿美元BIT  
5、波卡Polkadot发布2022年综述：平行链达74条，Dapp超过300个  
6、Euterpe完成首期歌曲版权NFT拍卖，成交价达底价3倍  
7、NFT市场Blur确认将于2023年1月底推出原生Token BLUR  
8、2022年加密市值前十：MATIC新晋上榜，LUNA、SOL等跌出前十  
9、加密资管公司Valkyrie提议成为GBTC新任管理者，并推出新基金以交易GBTC获利  
10、美国联邦检察官正调查SBF是否曾尝试转移资产或在未经批准情况下套现  
