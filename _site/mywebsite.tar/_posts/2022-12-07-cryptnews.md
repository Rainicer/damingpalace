---
layout: post
title:  "cryptnews-20221207"
---
1、Chainlink质押协议v0.1测试版已在以太坊主网上线  
2、CoinDesk现允许用户通过阅读文章等互动来赚取DESK Token  
3、GameStop进行大规模裁员，区块链钱包团队受到严重影响  
4、老牌Windows媒体播放器Winamp添加对以太坊和Polygon链上音乐NFT支持  
5、知情人士：英国正敲定加密行业监管计划，包括限制广告和外国加密公司  
6、彭博社：野村控股将加大对其加密子公司投入并计划在两年内实现盈利  
7、以太坊侧链Gnosis Chain：将进行合并，并将共识机制过渡至PoS  
8、NBA球星皮蓬推出首个数字球鞋NFT系列「Metawear」  
9、Decentraland宣布推出虚拟地块租赁业务  
10、去中心化索引协议The Graph公布在ETHIndia中使用The Graph的获奖项目  
