---
layout: post
title:  "cryptnews-20220903"
---
1、Gnosis Safe：以太坊合并后将仅支持PoS链，用户资产仍旧安全且无需执行任何操作  
2、Huobi Global发布中国大陆用户充币暂停上账服务公告  
3、华为、百度、高通等近200家单位加入「虚拟现实与元宇宙产业联盟」  
4、资管巨头贝莱德将使用Kraken的CF Benchmarks比特币指数推出其比特币产品  
5、《反电信网络诈骗法》发布：不得帮助他人通过虚拟货币交易等方式洗钱  
6、国际足联将推出基于Algorand网络的NFT平台「FIFA+ Collect」  
7、Cardano主网将于9月22日进行Vasil硬分叉  
8、全链域名服务商SPACE ID完成种子轮融资，Binance Labs领投  
9、V神新书《Proof of Stake》已获得24,576笔捐款，累计金额达153.93 ETH  
10、中国工程院院士张平：建议央行发行人民币稳定币CNYC，授权商业银行运营人民币稳定币业务  
