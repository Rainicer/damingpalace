---
layout: post
title:  "cryptnews-20221215"
---
1、资管公司WisdomTree将推出9只新区块链基金，已获美SEC批准  
2、PayPal与ConsenSys达成合作，美国用户可在MetaMask内购买ETH  
3、美消费者金融保护局：不会扩大对加密公司的执法  
4、StarkNet已启动治理第一阶段的「协议变更投票」，即将表决首次修改提议  
5、Glassnode：比特币短期实现波动率处于历史低点  
6、MakerDAO与GnosisDAO联手组建「DAO-to-DAO 战略联盟]  
7、Web3电子邮件平台Mailchain已支持向任意ENS或地址发送消息  
8、CoinW币赢协办「DEX、DEFI加密资产全新格局」主题AMA将于12月15日15时正式开启  
9、Social Trading平台TraderWagon上线一周年，交易量月均增长达74.2%  
10、经合组织呼吁就加密货币政策开展国际合作  
