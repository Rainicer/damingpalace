---
layout: post
title:  "cryptnews-20230121"
---
1、报告：2022年80%钱包首笔交易与NFT相关，远超DeFi  
2、Web3保险平台Fraud Buster Insurance(FBI)向FTX受影响用户和Uniswap OG发起空投  
3、NFT市场Blur推出移动端支持功能  
4、美联储理事沃勒：支持美联储下一次加息25个基点  
5、美SEC对Mango攻击者Avraham正式提出指控  
6、Blur宣布将Token发布日期推迟至2月14日  
7、Treasure DAO推出由Arbitrum支持的游戏创建者计划  
8、OpenSea上线数据服务功能模块Live Data  
9、Voyager拟于3月初确定债权人资产价值，预计用户资产可回收超51%  
10、PoS节点部署平台MarsProtocol完成1000万美元融资  
