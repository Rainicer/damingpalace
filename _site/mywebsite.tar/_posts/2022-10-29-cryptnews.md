---
layout: post
title:  "cryptnews-20221029"
---
1、Galaxy Digital：2022年已推出415支加密基金，共筹集1210亿美元，仅部署320亿美元  
2、数字货币钱包HyperPay拟以2000万美元收购中非数字银行  
3、Tether CTO：瑞士南部城市已有40家商户采用加密货币  
4、路透社：Binance正组建团队使加密技术助力推特  
5、日本加密交易平台Coincheck拟于2023年7月在纳斯达克上市  
6、知情人士：Huobi CEO预计将于11月初离职，此前早在收购完成时已提出离职申请  
7、Solidus：以太坊上8%的ERC-20 Token显示出欺诈活动特征  
8、zkSync在Code4rena平台启动漏洞赏金计划  
9、匿名加密巨鲸昨日将超4亿枚DOGE转入Binance  
10、zkSync 2.0主网正式进入第一阶段，将逐步开放生态项目和用户的访问权限  
