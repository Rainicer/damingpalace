---
layout: post
title:  "cryptnews-20221218"
---
1、韩国游戏巨头Wemade推出综合性区块链项目WeKonomy  
2、大连破获非法集资214亿元并利用虚拟货币洗钱的诈骗案  
3、巴林电信运营商子公司Stec Bahrain接受加密货币支付  
4、OKGroup创始人徐明星：阿里云宕机时间远超同行，跨区高可用的产品亦无法使用  
5、数据：Aptos主网交易总量突破5000万笔  
6、Gate.io：受运营商部分网络节点维护影响，充值提现服务将出现延缓  
7、Parity多签钱包黑客地址转移151枚ETH，并将41枚ETH转至eXch  
8、OKX：因云服务商问题出现短暂宕机，资金未受影响  
9、Binance已委托CryptoQuant出具比特币储备证明报告  
10、Raydium：攻击者或通过远程访问服务器获取私钥，正与Solana等团队合作定位攻击者  
