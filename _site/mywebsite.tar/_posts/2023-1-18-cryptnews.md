---
layout: post
title:  "cryptnews-20230118"
---
1、数据：Lido以太坊质押已支付奖励突破20万枚ETH  
2、加密支付网关Alchemy Pay已支持全球用户使用Apple Pay购买加密货币  
3、美司法部：正式认定Bitzlato是与俄罗斯非法金融有关的主要洗钱方  
4、万向区块链实验室、HashKey Group与W3ME联合举办「Hong Kong Web3 Festival 2023」  
5、21Shares推出加密货币质押指数ETP  
6、世界经济论坛发布「DAO工具包」报告，承认DAO有解决传统公司缺点的潜力  
7、泰国SEC发布加密托管商新规，要求建立数字钱包管理系统以确保客户安全  
8、数据：NIKE旗下NFT系列总收入超1.7亿美元  
9、Coinbase正式宣布停止其在日本的业务，并敦促当地客户在2月16日前提取资金  
10、报告：2022年美SEC共进行30起加密执法行动，较2021年增加50%  
