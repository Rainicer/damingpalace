---
layout: post
title:  "cryptnews-20221006"
---
1、LG集团旗下NFT市场LG Art Lab推出iOS应用Wallypto  
2、BNB市值突破480亿美元，超越USDC  
3、前美国总统候选人Andrew Yang加入Web3平台Pool Data担任顾问  
4、网络安全公司IriusRisk完成2870万美元B轮融资，将拓展Web3及区块链安全业务  
5、韩国检方已冻结Do Kwon此前转移至OKX、Kucoin的共计3313枚BTC  
6、欧盟已将加密货币列为IMF年会首要议题，将就加密立法发展问题与美国沟通  
7、金融科技独角兽Stash宣布已支持其用户投资BTC及ETH等加密资产  
8、慢雾：Transit Swap事件新增3个套利机器人及2个攻击模仿者，已知被盗损失总计超2800万美元  
9、Infura将于今日起弃用Optimism Kovan和Arbitrum Rinkeby测试网  
10、以太坊信标链验证者数量突破44万，总质押量接近1500万枚ETH  
