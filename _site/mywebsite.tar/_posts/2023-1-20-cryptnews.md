---
layout: post
title:  "cryptnews-20230120"
---
1、以太坊开发人员确认质押ETH提款的账户单位将由wei更改为gwei  
2、保时捷NFT铸造价格为每枚0.911 ETH  
3、面向稳定币和CBDC的通用数字支付网络（UDPN）于世界经济论坛推出  
4、阿联酋外贸大臣：加密货币将在阿联酋贸易中发挥重要作用  
5、李泽楷旗下公司电讯盈科于The Sandbox中推出元宇宙虚拟世界  
6、Blur宣布将Token发布日期推迟至2月14日  
7、Huobi发文回应「封禁用户账户」、「大量裁员且拒绝沟通」等市场质疑  
8、ZigZag将空投总供应量约2%的Token以奖励做市商  
9、瑞士法院裁定支持股东审计ConsenSys代号为「Project North Star」的创始交易  
10、Robinhood正式发布加密钱包APP，可充当「Web3浏览器」  
