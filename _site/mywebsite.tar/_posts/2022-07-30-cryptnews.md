---
layout: post
title:  "cryptnews-20220730"
---
1、Juno Network发布v.9.0.0版本，已恢复出块  
2、Axie Infinity侧链Ronin Network新增YGG等4个验证节点  
3、Glassnode：超10年未活跃的比特币供应量接近250万枚，创历史新高  
4、比特币矿企Bitfarms 为「The Bunker」矿场增加18兆瓦容量，算力增加200 PH/s  
5、CZ：监管框架正在为加密货币创造良好环境，行业正「朝着积极的方向前进」  
6、NFT SocialFi平台UneMeta完成500万美元融资，Jasmy Foundation领投  
7、Terraform Labs或将在Terra 2.0上构建DAO基础设施  
8、CoinFLEX：已进行较大规模裁员，将降低50%-60%的运营成本  
9、Optimism（OP）触及1.97美元后回落，24小时涨幅22.81%  
10、Upfront Ventures已为其三支新基金募集6.5亿美元资金  
