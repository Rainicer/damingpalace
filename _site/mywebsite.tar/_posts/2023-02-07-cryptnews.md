---
layout: post
title:  "cryptnews-20230207"
---
1、Binance：将于2月8日起暂停所有美元银行间转账，加密货币交易不受影响  
2、韩国文体部拟调整游戏赠品相关法规，禁止虚拟资产、NFT等作为赠品提供  
3、数据：昨日比特币区块体积平均数达2.2Mb，创历史纪录  
4、Tether、Bitfinex等将为土耳其灾后重建提供约26.5万美元援助  
5、OpenAI跻身全球TOP50网站，1月访问量突破6.72亿  
6、新火科技资深研究员Loki：2023年DeFi将继续在加密领域发挥更大的作用  
7、ENS DAO「出售1万枚ETH以支付未来两年运营费用」提案已获得通过  
8、MakerDAO联创拟设立1400万美元科学可持续发展基金「Scientific Sustainability Fund」  
9、韩国检察官和司法部官员上周前往塞尔维亚追捕Do Kwon  
10、Tether销毁20亿枚USDT作为此前链切换的一部分  
