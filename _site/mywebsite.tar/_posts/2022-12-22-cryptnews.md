---
layout: post
title:  "cryptnews-20221222"
---
1、Alameda前CEO和FTX联创分别面临最高110年、50年监禁  
2、Optimism Goerli测试网将于1月12日迁移至Bedrock架构  
3、美SEC主席：SEC首要任务仍是使用所有可用工具以使加密行业合规  
4、DeFi激励协议Fluidity上线以太坊主网  
5、欧易OKX获领英2022全球吸引力雇主奖，为此榜单唯一获奖的Web3科技公司  
6、Axie Infinity通过Google Play商店审核，计划首先在马来西亚试运行Origins  
7、The Block发布《2023数字资产展望》：Web3元宇宙浪潮将在2023年持续  
8、日本媒体巨头GREE已在Polygon上运行验证节点  
9、国家地理National Geographic将于2023年1月在Polygon区块链首发NFT  
10、华纳兄弟：《权力的游戏》NFT将于2023年1月10日发售  
