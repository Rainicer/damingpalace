---
layout: post
title:  "cryptnews-20220729"
---
1、1kx和Macro DAO联合发起Macro黑客松，加速NFT金融领域发展  
2、VeeFriends宣布完成种子轮融资，a16z领投  
3、The Sandbox推出头像Avatar专区  
4、以太坊市值重返2000亿美元上方  
5、过去24小时全网爆仓超5亿美元  
6、跨链解决方案Nomad公布种子轮融资中的其它投资者，包括Coinbase Ventures等  
7、以太坊突破1700美元，24小时涨幅13.98%  
8、体育社区平台Stadium Live宣布完成1000万美元的A轮融资，KB Partners和Union Square Ventures领投  
9、Juno Network因共识问题无法出块已暂停，将发布补丁  
10、Solana生态数据平台Step Finance收购NFT数据分析平台SolanaFloor  
