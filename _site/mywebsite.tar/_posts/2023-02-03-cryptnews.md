---
layout: post
title:  "cryptnews-20230203"
---
1、加密质押收益平台MoodMiner完成40万美元种子轮融资  
2、俄罗斯银行Sberbank预计5月前推出与以太坊兼容的DeFi平台  
3、育碧与Aleph.im达成合作拟在Tezos推出游戏NFT智能合约  
4、Binance与哈萨克斯坦国家银行发布「中亚数字资产行业和DeFi现状」双边报告  
5、瑞士宇舶表和村上隆推出彩虹宝石腕表NFT系列  
6、欧易Web3钱包与多链流动性协议Symbiosis达成合作  
7、跨链DeFi协议Prime Protocol上线Arbitrum测试网  
8、韩国关税厅计划成立打击加密货币非法交易的专门机构  
9、Binance支持香港警务处举办的虚拟资产调查课程，与香港警察携手合作打击网络犯罪  
10、Damus：正通过比特币闪电网络随机向用户发放小额比特币  
